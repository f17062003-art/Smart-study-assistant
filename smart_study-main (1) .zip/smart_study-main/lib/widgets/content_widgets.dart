import 'dart:io';

import 'package:flutter/material.dart';

import '../models/index.dart';
import '../utils/index.dart';

/// Small colored pill showing a subject. Subject colors are brand tokens that
/// read well on both light and dark backgrounds.
class SubjectChip extends StatelessWidget {
  final String subject;

  const SubjectChip({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    final color =
        AppColors.subjectColors[subject] ??
        Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimensions.paddingS,
        vertical: 3,
      ),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusS),
      ),
      child: Text(
        subject,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

/// Small outlined tag pill used on detail screens.
class TagChip extends StatelessWidget {
  final String tag;

  const TagChip({super.key, required this.tag});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimensions.paddingM,
        vertical: AppDimensions.paddingS,
      ),
      decoration: BoxDecoration(
        color: scheme.primary.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusM),
      ),
      child: Text(
        tag,
        style: Theme.of(
          context,
        ).textTheme.labelMedium?.copyWith(color: scheme.primary),
      ),
    );
  }
}

/// Card thumbnail that gracefully falls back to an icon when there is no image
/// or the file is missing/deleted.
class _Thumbnail extends StatelessWidget {
  static const double _height = 116;

  final String? path;
  final IconData fallbackIcon;
  final Color? fallbackColor;

  const _Thumbnail({
    required this.path,
    required this.fallbackIcon,
    this.fallbackColor,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final onFallback = fallbackColor != null
        ? Colors.white
        : scheme.onSurfaceVariant;

    Widget placeholder() => Container(
      height: _height,
      width: double.infinity,
      color: fallbackColor ?? scheme.surfaceContainerHighest,
      child: Icon(fallbackIcon, size: AppDimensions.iconL, color: onFallback),
    );

    if (path == null) return placeholder();
    return Image.file(
      File(path!),
      height: _height,
      width: double.infinity,
      fit: BoxFit.cover,
      errorBuilder: (_, _, _) => placeholder(),
    );
  }
}

/// Compact icon action used inside cards (smaller tap target than a default
/// [IconButton] so card rows stay tight).
class _CardAction extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final String? tooltip;

  const _CardAction({
    required this.icon,
    required this.color,
    required this.onTap,
    this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onTap,
      tooltip: tooltip,
      icon: Icon(icon, color: color, size: AppDimensions.iconM),
      visualDensity: VisualDensity.compact,
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(minWidth: 44, minHeight: 44),
    );
  }
}

class DocumentCard extends StatelessWidget {
  final Document document;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;
  final VoidCallback? onShare;
  final VoidCallback? onToggleFavorite;
  final bool showActions;

  const DocumentCard({
    super.key,
    required this.document,
    this.onTap,
    this.onDelete,
    this.onShare,
    this.onToggleFavorite,
    this.showActions = true,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            _Thumbnail(path: document.thumbnailPath, fallbackIcon: _icon()),
            Padding(
              padding: const EdgeInsets.all(AppDimensions.paddingM),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    document.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.titleSmall,
                  ),
                  const SizedBox(height: AppDimensions.paddingXS),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: SubjectChip(subject: document.subject),
                  ),
                  const SizedBox(height: AppDimensions.paddingXS),
                  Text(
                    DateTimeUtilities.formatRelativeTime(document.createdAt),
                    style: textTheme.bodySmall?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  if (showActions &&
                      (onToggleFavorite != null ||
                          onShare != null ||
                          onDelete != null)) ...[
                    const SizedBox(height: AppDimensions.paddingXS),
                    Row(
                      children: [
                        if (onToggleFavorite != null)
                          _CardAction(
                            icon: document.isFavorite
                                ? Icons.favorite
                                : Icons.favorite_border,
                            color: AppColors.error,
                            tooltip: 'Favorite',
                            onTap: onToggleFavorite!,
                          ),
                        if (onShare != null)
                          _CardAction(
                            icon: Icons.share_outlined,
                            color: scheme.primary,
                            tooltip: 'Share',
                            onTap: onShare!,
                          ),
                        const Spacer(),
                        if (onDelete != null)
                          _CardAction(
                            icon: Icons.delete_outline,
                            color: scheme.error,
                            tooltip: 'Delete',
                            onTap: onDelete!,
                          ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _icon() {
    switch (document.documentType) {
      case 'textbook':
        return Icons.menu_book_outlined;
      case 'pdf':
        return Icons.picture_as_pdf_outlined;
      case 'image':
        return Icons.image_outlined;
      default:
        return Icons.description_outlined;
    }
  }
}

class NoteCard extends StatelessWidget {
  final Note note;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;
  final VoidCallback? onToggleFavorite;

  const NoteCard({
    super.key,
    required this.note,
    this.onTap,
    this.onDelete,
    this.onToggleFavorite,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.paddingM),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      note.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: textTheme.titleSmall,
                    ),
                  ),
                  if (onToggleFavorite != null)
                    _CardAction(
                      icon: note.isFavorite
                          ? Icons.favorite
                          : Icons.favorite_border,
                      color: AppColors.error,
                      tooltip: 'Favorite',
                      onTap: onToggleFavorite!,
                    ),
                ],
              ),
              const SizedBox(height: AppDimensions.paddingXS),
              Align(
                alignment: Alignment.centerLeft,
                child: SubjectChip(subject: note.subject),
              ),
              const SizedBox(height: AppDimensions.paddingS),
              Text(
                note.content,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: textTheme.bodySmall?.copyWith(
                  color: scheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: AppDimensions.paddingS),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    DateTimeUtilities.formatRelativeTime(note.createdAt),
                    style: textTheme.bodySmall?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  if (onDelete != null)
                    _CardAction(
                      icon: Icons.delete_outline,
                      color: scheme.error,
                      tooltip: 'Delete',
                      onTap: onDelete!,
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class BookCard extends StatelessWidget {
  final Book book;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;
  final VoidCallback? onToggleFavorite;

  const BookCard({
    super.key,
    required this.book,
    this.onTap,
    this.onDelete,
    this.onToggleFavorite,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final subjectColor =
        AppColors.subjectColors[book.subject] ?? scheme.primary;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            _Thumbnail(
              path: book.coverImagePath,
              fallbackIcon: Icons.menu_book_outlined,
              fallbackColor: subjectColor,
            ),
            Padding(
              padding: const EdgeInsets.all(AppDimensions.paddingM),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    book.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.titleSmall,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    book.author,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.bodySmall?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  if (book.totalPages > 0) ...[
                    const SizedBox(height: AppDimensions.paddingS),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(
                        AppDimensions.borderRadiusS,
                      ),
                      child: LinearProgressIndicator(
                        value: (book.currentPage / book.totalPages).clamp(
                          0.0,
                          1.0,
                        ),
                        backgroundColor: scheme.surfaceContainerHighest,
                        minHeight: 4,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${book.currentPage}/${book.totalPages}',
                      style: textTheme.labelSmall?.copyWith(
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                  const SizedBox(height: AppDimensions.paddingXS),
                  Row(
                    children: [
                      if (onToggleFavorite != null)
                        _CardAction(
                          icon: book.isFavorite
                              ? Icons.favorite
                              : Icons.favorite_border,
                          color: AppColors.error,
                          tooltip: 'Favorite',
                          onTap: onToggleFavorite!,
                        ),
                      const Spacer(),
                      if (onDelete != null)
                        _CardAction(
                          icon: Icons.delete_outline,
                          color: scheme.error,
                          tooltip: 'Delete',
                          onTap: onDelete!,
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
