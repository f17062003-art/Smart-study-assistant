import 'dart:convert';
import 'dart:io' as io;

import 'package:googleai_dart/googleai_dart.dart';
import 'package:path_provider/path_provider.dart';

class AIService {
  final GoogleAIClient _client;

  // Supplied at build/run time via:
  //   --dart-define=GOOGLE_GENAI_API_KEY=your_key
  // No key is hard-coded, so the app never ships an embedded secret.
  static const _googleAIKey = String.fromEnvironment('GOOGLE_GENAI_API_KEY');

  /// Whether an API key was supplied via --dart-define at build time.
  static bool get isConfigured => _googleAIKey.isNotEmpty;

  AIService._(this._client);

  static Future<AIService> fromEnvironment() async {
    final client = GoogleAIClient.withApiKey(_googleAIKey);
    return AIService._(client);
  }

  Future<String> generateText(
    String prompt, {
    String model = 'gemini-2.5-flash',
  }) async {
    final response = await _client.models.generateContent(
      model: model,
      request: GenerateContentRequest(contents: [Content.text(prompt)]),
    );

    return response.text ?? '';
  }

  /// Generates an image for [prompt] using Gemini's image model and returns
  /// the path to the saved PNG, or null if no image was produced.
  Future<String?> generateImage(
    String prompt, {
    String model = 'gemini-2.5-flash-image',
  }) async {
    final response = await _client.models.generateContent(
      model: model,
      request: GenerateContentRequest(
        contents: [Content.text(prompt)],
        generationConfig: const GenerationConfig(
          responseModalities: [ResponseModality.text, ResponseModality.image],
        ),
      ),
    );

    final imageData = response.data;
    if (imageData == null || imageData.isEmpty) return null;

    final bytes = base64Decode(imageData);
    final dir = await getTemporaryDirectory();
    final file = io.File(
      '${dir.path}/ai_image_${DateTime.now().millisecondsSinceEpoch}.png',
    );
    await file.writeAsBytes(bytes);
    return file.path;
  }

  void close() => _client.close();
}
