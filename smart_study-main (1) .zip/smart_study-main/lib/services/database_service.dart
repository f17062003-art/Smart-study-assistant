import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/index.dart';
import '../objectbox.g.dart';
import '../utils/constants.dart';

/// Local database (ObjectBox) wrapper.
///
/// Extends [ChangeNotifier] so the UI updates reactively: every write notifies
/// listeners and screens reload in response. This keeps Home/Library/Settings
/// in sync after a capture, edit, or delete — no manual refresh needed.
class DatabaseService extends ChangeNotifier {
  late final Store _store;
  late final Box<Document> _documentBox;
  late final Box<Note> _noteBox;
  late final Box<Book> _bookBox;
  late final Box<Subject> _subjectBox;
  late final Box<SearchHistory> _searchHistoryBox;

  static final DatabaseService _instance = DatabaseService._internal();

  factory DatabaseService() {
    return _instance;
  }

  DatabaseService._internal();

  bool _initialized = false;

  // Initialize database
  Future<void> initialize() async {
    if (_initialized) return;

    _store = await openStore();
    _documentBox = _store.box<Document>();
    _noteBox = _store.box<Note>();
    _bookBox = _store.box<Book>();
    _subjectBox = _store.box<Subject>();
    _searchHistoryBox = _store.box<SearchHistory>();

    // Seed the default subjects on first launch so the Library filter and
    // subject pickers have data to work with.
    if (_subjectBox.isEmpty()) {
      _seedDefaultSubjects();
    }

    _initialized = true;
  }

  void _seedDefaultSubjects() {
    const uuid = Uuid();
    final subjects = DefaultSubjects.subjects.map((name) {
      final color = AppColors.subjectColors[name] ?? AppColors.primary;
      final hex =
          '#${(color.toARGB32() & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}';
      return Subject(subjectId: uuid.v4(), name: name, color: hex);
    }).toList();
    _subjectBox.putMany(subjects);
  }

  // Document operations
  Future<int> addDocument(Document document) async {
    final id = _documentBox.put(document);
    notifyListeners();
    return id;
  }

  Future<void> updateDocument(Document document) async {
    _documentBox.put(document);
    notifyListeners();
  }

  Future<void> deleteDocument(int id) async {
    _documentBox.remove(id);
    notifyListeners();
  }

  Future<Document?> getDocument(int id) async {
    return _documentBox.get(id);
  }

  List<Document> getAllDocuments() {
    return _documentBox.getAll();
  }

  List<Document> getDocumentsBySubject(String subject) {
    return _documentBox
        .query(Document_.subject.equals(subject))
        .order(Document_.createdAt, flags: Order.descending)
        .build()
        .find();
  }

  List<Document> searchDocuments(String query) {
    return _documentBox
        .query(
          Document_.title
              .contains(query, caseSensitive: false)
              .or(Document_.description.contains(query, caseSensitive: false)),
        )
        .order(Document_.lastAccessedAt, flags: Order.descending)
        .build()
        .find();
  }

  List<Document> getFavoriteDocuments() {
    return _documentBox
        .query(Document_.isFavorite.equals(true))
        .order(Document_.createdAt, flags: Order.descending)
        .build()
        .find();
  }

  List<Document> getRecentDocuments({int limit = 10}) {
    final query = _documentBox
        .query(Document_.isArchived.equals(false))
        .order(Document_.lastAccessedAt, flags: Order.descending)
        .build();
    query.limit = limit;
    final results = query.find();
    query.close();
    return results;
  }

  // Note operations
  Future<int> addNote(Note note) async {
    final id = _noteBox.put(note);
    notifyListeners();
    return id;
  }

  Future<void> updateNote(Note note) async {
    _noteBox.put(note);
    notifyListeners();
  }

  Future<void> deleteNote(int id) async {
    _noteBox.remove(id);
    notifyListeners();
  }

  Future<Note?> getNote(int id) async {
    return _noteBox.get(id);
  }

  List<Note> getAllNotes() {
    return _noteBox.getAll();
  }

  List<Note> getNotesBySubject(String subject) {
    return _noteBox
        .query(Note_.subject.equals(subject))
        .order(Note_.createdAt, flags: Order.descending)
        .build()
        .find();
  }

  List<Note> searchNotes(String query) {
    return _noteBox
        .query(
          Note_.title
              .contains(query, caseSensitive: false)
              .or(Note_.content.contains(query, caseSensitive: false)),
        )
        .order(Note_.lastAccessedAt, flags: Order.descending)
        .build()
        .find();
  }

  List<Note> getFavoriteNotes() {
    return _noteBox
        .query(Note_.isFavorite.equals(true))
        .order(Note_.createdAt, flags: Order.descending)
        .build()
        .find();
  }

  // Book operations
  Future<int> addBook(Book book) async {
    final id = _bookBox.put(book);
    notifyListeners();
    return id;
  }

  Future<void> updateBook(Book book) async {
    _bookBox.put(book);
    notifyListeners();
  }

  Future<void> deleteBook(int id) async {
    _bookBox.remove(id);
    notifyListeners();
  }

  Future<Book?> getBook(int id) async {
    return _bookBox.get(id);
  }

  Book? getBookByISBN(String isbn) {
    final results = _bookBox.query(Book_.isbn.equals(isbn)).build().find();
    return results.isEmpty ? null : results.first;
  }

  List<Book> getAllBooks() {
    return _bookBox.getAll();
  }

  List<Book> getBooksBySubject(String subject) {
    return _bookBox
        .query(Book_.subject.equals(subject))
        .order(Book_.addedAt, flags: Order.descending)
        .build()
        .find();
  }

  List<Book> searchBooks(String query) {
    return _bookBox
        .query(
          Book_.title
              .contains(query, caseSensitive: false)
              .or(Book_.author.contains(query, caseSensitive: false)),
        )
        .order(Book_.addedAt, flags: Order.descending)
        .build()
        .find();
  }

  List<Book> getFavoriteBooks() {
    return _bookBox
        .query(Book_.isFavorite.equals(true))
        .order(Book_.addedAt, flags: Order.descending)
        .build()
        .find();
  }

  List<Book> getBooksReadingStatus(String status) {
    return _bookBox
        .query(Book_.readingStatus.equals(status))
        .order(Book_.lastAccessedAt, flags: Order.descending)
        .build()
        .find();
  }

  // Subject operations
  Future<int> addSubject(Subject subject) async {
    final id = _subjectBox.put(subject);
    notifyListeners();
    return id;
  }

  Future<void> updateSubject(Subject subject) async {
    _subjectBox.put(subject);
    notifyListeners();
  }

  Future<void> deleteSubject(int id) async {
    _subjectBox.remove(id);
    notifyListeners();
  }

  Future<Subject?> getSubject(int id) async {
    return _subjectBox.get(id);
  }

  Subject? getSubjectByName(String name) {
    final results = _subjectBox
        .query(Subject_.name.equals(name))
        .build()
        .find();
    return results.isEmpty ? null : results.first;
  }

  List<Subject> getAllSubjects() {
    return _subjectBox.query().order(Subject_.name).build().find();
  }

  // Search history operations
  Future<int> addSearchHistory(SearchHistory history) async {
    final id = _searchHistoryBox.put(history);
    notifyListeners();
    return id;
  }

  List<SearchHistory> getSearchHistory({int limit = 10}) {
    final query = _searchHistoryBox
        .query()
        .order(SearchHistory_.searchedAt, flags: Order.descending)
        .build();
    query.limit = limit;
    final results = query.find();
    query.close();
    return results;
  }

  void clearSearchHistory() {
    _searchHistoryBox.removeAll();
    notifyListeners();
  }

  // Statistics
  int getDocumentCount() => _documentBox.count();
  int getNoteCount() => _noteBox.count();
  int getBookCount() => _bookBox.count();
  int getSubjectCount() => _subjectBox.count();

  // Clear all data
  Future<void> clearAllData() async {
    _documentBox.removeAll();
    _noteBox.removeAll();
    _bookBox.removeAll();
    _subjectBox.removeAll();
    _searchHistoryBox.removeAll();
    // Re-seed defaults so the app never ends up with an empty subject list.
    _seedDefaultSubjects();
    notifyListeners();
  }

  // Close database
  Future<void> close() async {
    _store.close();
  }
}
