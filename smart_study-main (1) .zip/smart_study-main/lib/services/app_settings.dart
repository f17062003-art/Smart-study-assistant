import 'package:flutter/material.dart';

import 'storage_service.dart';

/// App-wide reactive settings (currently the theme mode).
///
/// Implemented as a singleton to match the existing service style
/// ([StorageService] / [DatabaseService]). Screens read [themeMode] and call
/// [setThemeMode]; the root `MaterialApp` listens through a
/// [ValueListenableBuilder] so a change applies instantly *and* is persisted.
class AppSettings {
  AppSettings._internal();
  static final AppSettings instance = AppSettings._internal();

  final StorageService _storage = StorageService();

  /// Current theme mode. Defaults to system until [load] runs.
  final ValueNotifier<ThemeMode> themeMode = ValueNotifier<ThemeMode>(
    ThemeMode.system,
  );

  /// Populate from persisted preferences. Call once in `main()` after
  /// `StorageService.initialize()`.
  void load() {
    themeMode.value = themeModeFromString(_storage.getThemeMode());
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    if (themeMode.value == mode) return;
    themeMode.value = mode;
    await _storage.setThemeMode(stringFromThemeMode(mode));
  }

  static ThemeMode themeModeFromString(String? value) {
    switch (value) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  static String stringFromThemeMode(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
        return 'system';
    }
  }
}
