import 'chat_message.dart';

/// A single saved AI conversation: an ordered list of [ChatMessage]s plus the
/// metadata used to list and resume it from the chat history.
class ChatSession {
  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<ChatMessage> messages;

  const ChatSession({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    required this.messages,
  });

  /// A short preview drawn from the first non-empty message.
  String get preview {
    for (final m in messages) {
      if (m.isUser && m.text.trim().isNotEmpty) return m.text.trim();
    }
    for (final m in messages) {
      if (m.text.trim().isNotEmpty) return m.text.trim();
    }
    return 'Empty conversation';
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
    'messages': messages.map((m) => m.toJson()).toList(),
  };

  factory ChatSession.fromJson(Map<String, dynamic> json) => ChatSession(
    id: json['id'] as String,
    title: json['title'] as String,
    createdAt: DateTime.parse(json['createdAt'] as String),
    updatedAt: DateTime.parse(json['updatedAt'] as String),
    messages: (json['messages'] as List<dynamic>)
        .map((e) => ChatMessage.fromJson(e as Map<String, dynamic>))
        .toList(),
  );
}
