import 'dart:async';

import 'package:flutter/material.dart';
import '../models/index.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen>
    with SingleTickerProviderStateMixin {
  final SearchService _searchService = SearchService();
  final TextEditingController _searchController = TextEditingController();
  Timer? _debounce;

  late TabController _tabController;
  Map<String, dynamic> _results = _emptyResults();
  List<SearchHistory> _history = [];
  bool _isSearching = false;

  static Map<String, dynamic> _emptyResults() => {
    'documents': <Document>[],
    'notes': <Note>[],
    'books': <Book>[],
    'total': 0,
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadHistory();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  void _loadHistory() {
    setState(() => _history = _searchService.getSearchHistory());
  }

  bool get _hasQuery => _searchController.text.trim().isNotEmpty;

  void _onQueryChanged(String value) {
    _debounce?.cancel();
    setState(() {}); // refresh clear button + history/results toggle
    if (value.trim().isEmpty) {
      _results = _emptyResults();
      return;
    }
    _debounce = Timer(
      const Duration(milliseconds: 350),
      () => _performSearch(value.trim()),
    );
  }

  Future<void> _performSearch(String query) async {
    if (query.isEmpty) return;
    setState(() => _isSearching = true);
    try {
      final results = await _searchService.globalSearch(query);
      if (mounted) setState(() => _results = results);
      _loadHistory();
    } catch (e) {
      if (mounted) SnackBarHelper.showError(context, 'Search failed: $e');
    } finally {
      if (mounted) setState(() => _isSearching = false);
    }
  }

  void _runFromHistory(String query) {
    _searchController.text = query;
    _performSearch(query);
  }

  void _clearQuery() {
    _searchController.clear();
    setState(() => _results = _emptyResults());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingM),
            child: TextField(
              controller: _searchController,
              textInputAction: TextInputAction.search,
              onChanged: _onQueryChanged,
              onSubmitted: (v) => _performSearch(v.trim()),
              decoration: InputDecoration(
                hintText: 'Search documents, notes, books…',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _hasQuery
                    ? IconButton(
                        tooltip: 'Clear',
                        icon: const Icon(Icons.clear),
                        onPressed: _clearQuery,
                      )
                    : null,
              ),
            ),
          ),
          Expanded(child: _hasQuery ? _buildResults() : _buildHistory()),
        ],
      ),
    );
  }

  Widget _buildHistory() {
    if (_history.isEmpty) {
      return const EmptyWidget(
        title: 'Search your library',
        message: 'Find documents, notes and books by title, content or tag.',
        icon: Icons.search,
      );
    }
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: AppDimensions.paddingM),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: AppDimensions.paddingS),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Recent searches',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              TextButton(
                onPressed: () {
                  _searchService.clearSearchHistory();
                  _loadHistory();
                },
                child: const Text('Clear'),
              ),
            ],
          ),
        ),
        ..._history.map(
          (h) => ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.history),
            title: Text(h.query),
            subtitle: Text('${h.resultCount} results'),
            trailing: const Icon(Icons.north_west, size: AppDimensions.iconM),
            onTap: () => _runFromHistory(h.query),
          ),
        ),
      ],
    );
  }

  Widget _buildResults() {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final docs = (_results['documents'] as List).cast<Document>();
    final notes = (_results['notes'] as List).cast<Note>();
    final books = (_results['books'] as List).cast<Book>();
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppDimensions.paddingM,
            ),
            child: Text(
              '${_results['total']} results',
              style: textTheme.bodySmall?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ),
        ),
        TabBar(
          controller: _tabController,
          labelColor: scheme.primary,
          unselectedLabelColor: scheme.onSurfaceVariant,
          indicatorColor: scheme.primary,
          dividerColor: Colors.transparent,
          tabs: [
            Tab(text: 'Docs (${docs.length})'),
            Tab(text: 'Notes (${notes.length})'),
            Tab(text: 'Books (${books.length})'),
          ],
        ),
        Expanded(
          child: _isSearching
              ? const LoadingWidget()
              : TabBarView(
                  controller: _tabController,
                  children: [
                    _docList(docs),
                    _noteList(notes),
                    _bookGrid(books),
                  ],
                ),
        ),
      ],
    );
  }

  Widget _docList(List<Document> docs) {
    if (docs.isEmpty) {
      return const EmptyWidget(
        title: 'No documents',
        message: 'Try a different search term.',
        icon: Icons.description_outlined,
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppDimensions.paddingM),
      itemCount: docs.length,
      separatorBuilder: (_, _) =>
          const SizedBox(height: AppDimensions.paddingM),
      itemBuilder: (_, i) => DocumentCard(
        document: docs[i],
        showActions: false,
        onTap: () => Navigator.pushNamed(
          context,
          '/document_detail',
          arguments: docs[i],
        ),
      ),
    );
  }

  Widget _noteList(List<Note> notes) {
    if (notes.isEmpty) {
      return const EmptyWidget(
        title: 'No notes',
        message: 'Try a different search term.',
        icon: Icons.sticky_note_2_outlined,
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppDimensions.paddingM),
      itemCount: notes.length,
      separatorBuilder: (_, _) =>
          const SizedBox(height: AppDimensions.paddingM),
      itemBuilder: (_, i) => NoteCard(
        note: notes[i],
        onTap: () =>
            Navigator.pushNamed(context, '/note_detail', arguments: notes[i]),
      ),
    );
  }

  Widget _bookGrid(List<Book> books) {
    if (books.isEmpty) {
      return const EmptyWidget(
        title: 'No books',
        message: 'Try a different search term.',
        icon: Icons.menu_book_outlined,
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.all(AppDimensions.paddingM),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: AppDimensions.paddingM,
        crossAxisSpacing: AppDimensions.paddingM,
        childAspectRatio: 0.68,
      ),
      itemCount: books.length,
      itemBuilder: (_, i) => BookCard(
        book: books[i],
        onTap: () =>
            Navigator.pushNamed(context, '/book_detail', arguments: books[i]),
      ),
    );
  }
}
