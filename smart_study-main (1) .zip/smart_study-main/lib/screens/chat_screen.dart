import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:uuid/uuid.dart';

import '../models/chat_message.dart';
import '../models/chat_session.dart';
import '../services/ai_service.dart';
import '../services/chat_history_service.dart';
import '../utils/index.dart';
import '../widgets/index.dart';
import 'chat_history_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final _uuid = const Uuid();
  final _historyService = ChatHistoryService();
  AIService? _aiService;
  List<ChatMessage> _messages = [];
  late String _sessionId;
  late DateTime _sessionCreatedAt;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _sessionId = _uuid.v4();
    _sessionCreatedAt = DateTime.now();
    _init();
  }

  Future<void> _init() async {
    final svc = await AIService.fromEnvironment();
    final sessions = await _historyService.loadSessions();
    if (!mounted) return;
    setState(() {
      _aiService = svc;
      // Resume the most recent conversation, if there is one.
      if (sessions.isNotEmpty && sessions.first.messages.isNotEmpty) {
        final latest = sessions.first;
        _sessionId = latest.id;
        _sessionCreatedAt = latest.createdAt;
        _messages = List.of(latest.messages);
      }
    });
  }

  /// Title for the current conversation, taken from the first user message.
  String _deriveTitle() {
    for (final m in _messages) {
      if (m.isUser && m.text.trim().isNotEmpty) {
        final t = m.text.trim();
        return t.length <= 40 ? t : '${t.substring(0, 40)}…';
      }
    }
    return 'New chat';
  }

  /// Saves the current conversation to history (skips empty ones).
  Future<void> _persist() async {
    if (_messages.isEmpty) return;
    await _historyService.saveSession(
      ChatSession(
        id: _sessionId,
        title: _deriveTitle(),
        createdAt: _sessionCreatedAt,
        updatedAt: DateTime.now(),
        messages: List.of(_messages),
      ),
    );
  }

  Future<void> _startNewChat() async {
    if (_isLoading) return;
    await _persist();
    if (!mounted) return;
    setState(() {
      _sessionId = _uuid.v4();
      _sessionCreatedAt = DateTime.now();
      _messages = [];
      _controller.clear();
    });
  }

  Future<void> _openHistory() async {
    await _persist();
    if (!mounted) return;
    final selected = await Navigator.push<ChatSession>(
      context,
      MaterialPageRoute(builder: (_) => const ChatHistoryScreen()),
    );
    if (selected == null || !mounted) return;
    setState(() {
      _sessionId = selected.id;
      _sessionCreatedAt = selected.createdAt;
      _messages = List.of(selected.messages);
    });
    _scrollToBottom();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    _aiService?.close();
    super.dispose();
  }

  Future<void> _sendText() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _aiService == null) return;
    final userMsg = ChatMessage(id: _uuid.v4(), text: text, isUser: true);
    final botPlaceholder = ChatMessage(id: _uuid.v4(), text: '', isUser: false);

    setState(() {
      _messages.add(userMsg);
      _messages.add(botPlaceholder);
      _controller.clear();
      _isLoading = true;
    });
    _scrollToBottom();

    try {
      final reply = await _aiService!.generateText(text);
      await _typeOutReply(_messages.indexOf(botPlaceholder), reply);
    } catch (e) {
      final errIndex = _messages.indexOf(botPlaceholder);
      if (errIndex != -1) {
        setState(() {
          _messages[errIndex] = _messages[errIndex].copyWith(text: 'Error: $e');
        });
      }
    } finally {
      setState(() => _isLoading = false);
      await _persist();
    }
  }

  Future<void> _generateImage() async {
    final prompt = _controller.text.trim();
    if (prompt.isEmpty || _aiService == null) return;
    final userMsg = ChatMessage(id: _uuid.v4(), text: prompt, isUser: true);
    setState(() {
      _messages.add(userMsg);
      _controller.clear();
      _isLoading = true;
    });
    _scrollToBottom();

    try {
      final path = await _aiService!.generateImage(prompt);
      setState(() {
        _messages.add(
          ChatMessage(
            id: _uuid.v4(),
            text: path == null ? 'No image was generated.' : '',
            isUser: false,
            imageUrl: path,
          ),
        );
      });
    } catch (e) {
      setState(() {
        _messages.add(
          ChatMessage(id: _uuid.v4(), text: 'Image error: $e', isUser: false),
        );
      });
    } finally {
      setState(() => _isLoading = false);
      await _persist();
    }
  }

  Future<void> _typeOutReply(int index, String reply) async {
    if (index < 0 || index >= _messages.length) return;
    const chunkSize = 4;
    for (var i = chunkSize; i <= reply.length; i += chunkSize) {
      setState(() {
        _messages[index] = _messages[index].copyWith(
          text: reply.substring(0, i),
        );
      });
      _scrollToBottom();
      await Future.delayed(const Duration(milliseconds: 25));
    }
    if (_messages[index].text != reply) {
      setState(() {
        _messages[index] = _messages[index].copyWith(text: reply);
      });
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        centerTitle: false,
        titleSpacing: AppDimensions.paddingL,
        iconTheme: const IconThemeData(color: Colors.white),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        flexibleSpace: Container(
          decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(AppDimensions.paddingXS),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.22),
              ),
              child: const Icon(
                Icons.smart_toy_outlined,
                color: Colors.white,
                size: AppDimensions.iconM,
              ),
            ),
            const SizedBox(width: AppDimensions.paddingM),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'AI Assistant',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.titleMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    'Powered by Gemini',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.bodySmall?.copyWith(
                      color: Colors.white.withValues(alpha: 0.85),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Chat history',
            style: IconButton.styleFrom(foregroundColor: Colors.white),
            icon: const Icon(Icons.history),
            onPressed: _openHistory,
          ),
          IconButton(
            tooltip: 'New chat',
            style: IconButton.styleFrom(foregroundColor: Colors.white),
            icon: const Icon(Icons.add_comment_outlined),
            onPressed: _startNewChat,
          ),
          IconButton(
            tooltip: 'Close',
            style: IconButton.styleFrom(foregroundColor: Colors.white),
            icon: const Icon(Icons.close),
            onPressed: () => Navigator.of(context).maybePop(),
          ),
          const SizedBox(width: AppDimensions.paddingXS),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: _messages.isEmpty
                  ? const EmptyWidget(
                      title: 'Ask me anything',
                      message: 'Quick answers, summaries and study help.',
                      icon: Icons.smart_toy_outlined,
                    )
                  : ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.symmetric(
                        vertical: AppDimensions.paddingM,
                      ),
                      itemCount: _messages.length,
                      itemBuilder: (context, i) => _buildMessage(_messages[i]),
                    ),
            ),
            if (_isLoading) const LinearProgressIndicator(minHeight: 3),
            _buildInputBar(scheme),
          ],
        ),
      ),
    );
  }

  Widget _buildMessage(ChatMessage m) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final isUser = m.isUser;
    final bubbleColor = isUser
        ? scheme.primary
        : scheme.surfaceContainerHighest;
    final textColor = isUser ? scheme.onPrimary : scheme.onSurface;
    final radius = BorderRadius.only(
      topLeft: const Radius.circular(AppDimensions.borderRadiusXL),
      topRight: const Radius.circular(AppDimensions.borderRadiusXL),
      bottomLeft: Radius.circular(
        isUser ? AppDimensions.borderRadiusXL : AppDimensions.borderRadiusS,
      ),
      bottomRight: Radius.circular(
        isUser ? AppDimensions.borderRadiusS : AppDimensions.borderRadiusXL,
      ),
    );

    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 6,
        horizontal: AppDimensions.paddingL,
      ),
      child: Align(
        alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: isUser
              ? CrossAxisAlignment.end
              : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.8,
              ),
              padding: const EdgeInsets.all(AppDimensions.paddingM),
              decoration: BoxDecoration(
                color: bubbleColor,
                borderRadius: radius,
              ),
              child: m.imageUrl != null && m.imageUrl!.isNotEmpty
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(
                            AppDimensions.borderRadiusL,
                          ),
                          child: Image.file(
                            File(m.imageUrl!),
                            fit: BoxFit.cover,
                            errorBuilder: (_, _, _) => Text(
                              'Image unavailable',
                              style: textTheme.bodySmall?.copyWith(
                                color: textColor,
                              ),
                            ),
                          ),
                        ),
                        if (m.text.isNotEmpty) ...[
                          const SizedBox(height: AppDimensions.paddingS),
                          Text(
                            m.text,
                            style: textTheme.bodyMedium?.copyWith(
                              color: textColor,
                            ),
                          ),
                        ],
                      ],
                    )
                  : isUser
                  ? Text(
                      m.text,
                      style: textTheme.bodyLarge?.copyWith(color: textColor),
                    )
                  : m.text.isEmpty
                  ? Text(
                      'Thinking…',
                      style: textTheme.bodyLarge?.copyWith(
                        color: textColor.withValues(alpha: 0.7),
                      ),
                    )
                  : MarkdownBody(
                      data: m.text,
                      selectable: false,
                      styleSheet:
                          MarkdownStyleSheet.fromTheme(
                            Theme.of(context),
                          ).copyWith(
                            p: textTheme.bodyLarge?.copyWith(color: textColor),
                            listBullet: textTheme.bodyLarge?.copyWith(
                              color: textColor,
                            ),
                            strong: textTheme.bodyLarge?.copyWith(
                              color: textColor,
                              fontWeight: FontWeight.w700,
                            ),
                            em: textTheme.bodyLarge?.copyWith(
                              color: textColor,
                              fontStyle: FontStyle.italic,
                            ),
                            a: TextStyle(color: scheme.primary),
                            code: textTheme.bodyMedium?.copyWith(
                              color: textColor,
                              fontFamily: 'monospace',
                              backgroundColor: Colors.transparent,
                            ),
                            codeblockPadding: const EdgeInsets.all(
                              AppDimensions.paddingS,
                            ),
                            codeblockDecoration: BoxDecoration(
                              color: scheme.surface.withValues(alpha: 0.6),
                              borderRadius: BorderRadius.circular(
                                AppDimensions.borderRadiusS,
                              ),
                            ),
                            blockquoteDecoration: BoxDecoration(
                              color: scheme.surface.withValues(alpha: 0.4),
                              borderRadius: BorderRadius.circular(
                                AppDimensions.borderRadiusS,
                              ),
                            ),
                          ),
                    ),
            ),
            if (!isUser &&
                m.text.isNotEmpty &&
                (m.imageUrl == null || m.imageUrl!.isEmpty))
              _CopyButton(text: m.text),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar(ColorScheme scheme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        AppDimensions.paddingM,
        AppDimensions.paddingS,
        AppDimensions.paddingM,
        AppDimensions.paddingM,
      ),
      decoration: BoxDecoration(
        color: scheme.surface,
        border: Border(top: BorderSide(color: scheme.outlineVariant)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _isLoading ? null : _sendText(),
                decoration: const InputDecoration(hintText: 'Ask anything…'),
              ),
            ),
            const SizedBox(width: AppDimensions.paddingS),
            IconButton(
              tooltip: 'Generate image',
              onPressed: _isLoading ? null : _generateImage,
              icon: const Icon(Icons.image_outlined),
            ),
            IconButton.filled(
              tooltip: 'Send',
              onPressed: _isLoading ? null : _sendText,
              icon: const Icon(Icons.send),
              style: IconButton.styleFrom(
                backgroundColor: scheme.primary,
                foregroundColor: scheme.onPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// A compact "Copy" affordance shown beneath each AI reply.
class _CopyButton extends StatelessWidget {
  const _CopyButton({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 2, left: AppDimensions.paddingXS),
      child: TextButton.icon(
        onPressed: () {
          Clipboard.setData(ClipboardData(text: text));
          SnackBarHelper.showInfo(context, 'Copied to clipboard');
        },
        icon: const Icon(Icons.copy_rounded, size: 15),
        label: const Text('Copy'),
        style: TextButton.styleFrom(
          minimumSize: const Size(0, 36),
          padding: const EdgeInsets.symmetric(
            horizontal: AppDimensions.paddingS,
            vertical: 2,
          ),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          foregroundColor: theme.colorScheme.onSurfaceVariant,
          textStyle: theme.textTheme.labelSmall,
        ),
      ),
    );
  }
}
