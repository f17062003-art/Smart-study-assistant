import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models/index.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class BookDetailScreen extends StatefulWidget {
  final Book book;

  const BookDetailScreen({super.key, required this.book});

  @override
  State<BookDetailScreen> createState() => _BookDetailScreenState();
}

class _BookDetailScreenState extends State<BookDetailScreen> {
  final DatabaseService _databaseService = DatabaseService();
  late Book _book;
  late TextEditingController _currentPageController;

  @override
  void initState() {
    super.initState();
    _book = widget.book;
    _currentPageController = TextEditingController(
      text: _book.currentPage.toString(),
    );
  }

  @override
  void dispose() {
    _currentPageController.dispose();
    super.dispose();
  }

  Future<void> _updateReadingProgress() async {
    final currentPage = int.tryParse(_currentPageController.text) ?? 0;
    final updated = _book.copyWith(currentPage: currentPage);
    await _databaseService.updateBook(updated);
    if (!mounted) return;
    setState(() => _book = updated);
    SnackBarHelper.showSuccess(context, 'Progress updated');
  }

  Future<void> _updateReadingStatus(String status) async {
    final updated = _book.copyWith(readingStatus: status);
    await _databaseService.updateBook(updated);
    if (mounted) setState(() => _book = updated);
  }

  Future<void> _toggleFavorite() async {
    final updated = _book.copyWith(isFavorite: !_book.isFavorite);
    await _databaseService.updateBook(updated);
    if (mounted) setState(() => _book = updated);
  }

  Future<void> _shareBook() async {
    final buffer = StringBuffer(_book.title);
    if (_book.author.isNotEmpty) buffer.write('\nby ${_book.author}');
    if (_book.isbn.isNotEmpty) buffer.write('\nISBN: ${_book.isbn}');
    if ((_book.description ?? '').trim().isNotEmpty) {
      buffer.write('\n\n${_book.description!.trim()}');
    }
    final text = buffer.toString();
    final cover = _book.coverImagePath;
    if (cover != null && File(cover).existsSync()) {
      await Share.shareXFiles([XFile(cover)], text: text, subject: _book.title);
    } else {
      await Share.share(text, subject: _book.title);
    }
  }

  Future<void> _archiveBook() async {
    await _databaseService.updateBook(_book.copyWith(isArchived: true));
    if (mounted) {
      SnackBarHelper.showSuccess(context, 'Archived');
      Navigator.pop(context);
    }
  }

  Future<void> _deleteBook() async {
    final scheme = Theme.of(context).colorScheme;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete book?'),
        content: const Text('This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: scheme.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _databaseService.deleteBook(_book.id);
      if (mounted) {
        SnackBarHelper.showSuccess(context, 'Book deleted');
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final subjectColor =
        AppColors.subjectColors[_book.subject] ?? scheme.primary;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book'),
        actions: [
          IconButton(
            tooltip: 'Favorite',
            icon: Icon(
              _book.isFavorite ? Icons.favorite : Icons.favorite_border,
              color: AppColors.error,
            ),
            onPressed: _toggleFavorite,
          ),
          IconButton(
            tooltip: 'Share',
            icon: const Icon(Icons.share_outlined),
            onPressed: _shareBook,
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'archive') _archiveBook();
              if (v == 'delete') _deleteBook();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'archive', child: Text('Archive')),
              PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingM),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCover(subjectColor),
            const SizedBox(height: AppDimensions.paddingXL),
            Text(_book.title, style: textTheme.headlineSmall),
            const SizedBox(height: AppDimensions.paddingXS),
            Text(
              'by ${_book.author}',
              style: textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: AppDimensions.paddingM),
            SubjectChip(subject: _book.subject),
            const SizedBox(height: AppDimensions.paddingXL),
            Text('Reading status', style: textTheme.titleMedium),
            const SizedBox(height: AppDimensions.paddingM),
            SegmentedButton<String>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: 'unread', label: Text('Unread')),
                ButtonSegment(value: 'reading', label: Text('Reading')),
                ButtonSegment(value: 'completed', label: Text('Done')),
              ],
              selected: {_book.readingStatus},
              onSelectionChanged: (s) => _updateReadingStatus(s.first),
            ),
            if (_book.totalPages > 0) ...[
              const SizedBox(height: AppDimensions.paddingXL),
              Text('Reading progress', style: textTheme.titleMedium),
              const SizedBox(height: AppDimensions.paddingM),
              ClipRRect(
                borderRadius: BorderRadius.circular(
                  AppDimensions.borderRadiusS,
                ),
                child: LinearProgressIndicator(
                  value: (_book.currentPage / _book.totalPages).clamp(0.0, 1.0),
                  backgroundColor: scheme.surfaceContainerHighest,
                  minHeight: 8,
                ),
              ),
              const SizedBox(height: AppDimensions.paddingM),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: CustomTextField(
                      label: 'Current page',
                      controller: _currentPageController,
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(width: AppDimensions.paddingM),
                  Padding(
                    padding: const EdgeInsets.only(
                      bottom: AppDimensions.paddingM,
                    ),
                    child: Text(
                      '/ ${_book.totalPages}',
                      style: textTheme.titleMedium,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.paddingM),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _updateReadingProgress,
                  child: const Text('Update progress'),
                ),
              ),
            ],
            const SizedBox(height: AppDimensions.paddingXL),
            Text('Book information', style: textTheme.titleMedium),
            const SizedBox(height: AppDimensions.paddingS),
            _buildInfoRow('ISBN', _book.isbn),
            if (_book.publisher != null)
              _buildInfoRow('Publisher', _book.publisher!),
            if (_book.publicationDate != null)
              _buildInfoRow('Published', _book.publicationDate!),
            _buildInfoRow('Added', DateTimeUtilities.formatDate(_book.addedAt)),
          ],
        ),
      ),
    );
  }

  Widget _buildCover(Color subjectColor) {
    final radius = BorderRadius.circular(AppDimensions.borderRadiusL);
    Widget placeholder() => Container(
      height: 240,
      width: double.infinity,
      decoration: BoxDecoration(color: subjectColor, borderRadius: radius),
      child: const Center(
        child: Icon(
          Icons.menu_book_outlined,
          size: AppDimensions.iconXL,
          color: Colors.white,
        ),
      ),
    );
    if (_book.coverImagePath == null) return placeholder();
    return ClipRRect(
      borderRadius: radius,
      child: Image.file(
        File(_book.coverImagePath!),
        height: 240,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => placeholder(),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppDimensions.paddingS),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: textTheme.bodyMedium?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}
