import 'package:flutter/material.dart';

import '../models/index.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final DatabaseService _databaseService = DatabaseService();
  List<Document> _recentDocuments = [];
  List<Note> _recentNotes = [];
  int _documentCount = 0;
  int _noteCount = 0;
  int _bookCount = 0;

  @override
  void initState() {
    super.initState();
    _databaseService.addListener(_onDataChanged);
    _loadData();
  }

  @override
  void dispose() {
    _databaseService.removeListener(_onDataChanged);
    super.dispose();
  }

  void _onDataChanged() {
    if (mounted) _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _recentDocuments = _databaseService.getRecentDocuments(limit: 5);
      _recentNotes = _databaseService
          .getAllNotes()
          .where((note) => !note.isArchived)
          .take(5)
          .toList();
      _documentCount = _databaseService.getDocumentCount();
      _noteCount = _databaseService.getNoteCount();
      _bookCount = _databaseService.getBookCount();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppDimensions.paddingM),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: AppDimensions.paddingXL),
              _buildSearchBar(),
              const SizedBox(height: AppDimensions.paddingXL),
              _buildStats(),
              const SizedBox(height: AppDimensions.paddingXL),
              Text(
                'Quick Actions',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: AppDimensions.paddingM),
              _buildQuickActions(),
              const SizedBox(height: AppDimensions.paddingXL),
              if (_recentDocuments.isNotEmpty) ...[
                _buildSectionHeader(
                  title: 'Recent Documents',
                  actionLabel: 'View all',
                  onAction: () => Navigator.pushNamed(context, '/library'),
                ),
                const SizedBox(height: AppDimensions.paddingM),
                ListView.separated(
                  separatorBuilder: (_, _) =>
                      const SizedBox(height: AppDimensions.paddingM),
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _recentDocuments.length,
                  itemBuilder: (context, index) => DocumentCard(
                    document: _recentDocuments[index],
                    showActions: false,
                    onTap: () => Navigator.pushNamed(
                      context,
                      '/document_detail',
                      arguments: _recentDocuments[index],
                    ),
                  ),
                ),
                const SizedBox(height: AppDimensions.paddingXL),
              ],
              if (_recentNotes.isNotEmpty) ...[
                _buildSectionHeader(title: 'Recent Notes'),
                const SizedBox(height: AppDimensions.paddingM),
                ListView.separated(
                  separatorBuilder: (_, _) =>
                      const SizedBox(height: AppDimensions.paddingM),
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _recentNotes.length,
                  itemBuilder: (context, index) => NoteCard(
                    note: _recentNotes[index],
                    onTap: () => Navigator.pushNamed(
                      context,
                      '/note_detail',
                      arguments: _recentNotes[index],
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    final textTheme = Theme.of(context).textTheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppDimensions.paddingL),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusXXL),
        gradient: AppColors.primaryGradient,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            AppStrings.appName,
            style: textTheme.headlineMedium?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: AppDimensions.paddingXS),
          Text(
            'Your premium study workspace.',
            style: textTheme.bodyMedium?.copyWith(color: Colors.white70),
          ),
          const SizedBox(height: AppDimensions.paddingL),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => Navigator.pushNamed(context, '/ai_chat'),
              icon: const Icon(Icons.smart_toy_outlined),
              label: const Text('Ask AI Assistant'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: AppColors.primaryDark,
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return CustomCard(
      margin: EdgeInsets.zero,
      onTap: () => Navigator.pushNamed(context, '/search'),
      child: Row(
        children: [
          Icon(Icons.search, color: scheme.onSurfaceVariant),
          const SizedBox(width: AppDimensions.paddingM),
          Expanded(
            child: Text(
              'Search documents, notes, or books',
              style: textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStats() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _buildStatCard(
            'Documents',
            _documentCount.toString(),
            Icons.description_outlined,
            AppColors.primary,
          ),
          const SizedBox(width: AppDimensions.paddingM),
          _buildStatCard(
            'Notes',
            _noteCount.toString(),
            Icons.sticky_note_2_outlined,
            AppColors.secondary,
          ),
          const SizedBox(width: AppDimensions.paddingM),
          _buildStatCard(
            'Books',
            _bookCount.toString(),
            Icons.menu_book_outlined,
            AppColors.accent,
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActions() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: AppDimensions.paddingM,
      crossAxisSpacing: AppDimensions.paddingM,
      childAspectRatio: 1.6,
      children: [
        _buildActionButton(
          'Scan Document',
          Icons.document_scanner_outlined,
          AppColors.primary,
          () => Navigator.pushNamed(context, '/capture_document'),
        ),
        _buildActionButton(
          'Take Photo',
          Icons.camera_alt_outlined,
          AppColors.secondary,
          () => Navigator.pushNamed(context, '/capture_photo'),
        ),
        _buildActionButton(
          'Add Note',
          Icons.edit_note_outlined,
          AppColors.accent,
          () => Navigator.pushNamed(context, '/note_editor'),
        ),
        _buildActionButton(
          'Scan Barcode',
          Icons.qr_code_2_outlined,
          AppColors.warning,
          () => Navigator.pushNamed(context, '/barcode'),
        ),
      ],
    );
  }

  Widget _buildSectionHeader({
    required String title,
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        if (actionLabel != null && onAction != null)
          TextButton(onPressed: onAction, child: Text(actionLabel)),
      ],
    );
  }

  Widget _buildStatCard(
    String label,
    String value,
    IconData icon,
    Color color,
  ) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Container(
      width: 150,
      padding: const EdgeInsets.all(AppDimensions.paddingM),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusXL),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(AppDimensions.paddingS),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(AppDimensions.borderRadiusL),
            ),
            child: Icon(icon, color: color, size: AppDimensions.iconM),
          ),
          const SizedBox(height: AppDimensions.paddingM),
          Text(
            value,
            style: textTheme.headlineSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: AppDimensions.paddingXXS),
          Text(
            label,
            style: textTheme.bodySmall?.copyWith(
              color: scheme.onSurfaceVariant,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(
    String label,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    final textTheme = Theme.of(context).textTheme;
    return Material(
      color: color.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(AppDimensions.borderRadiusXL),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.paddingM),
          child: Row(
            children: [
              Icon(icon, color: color, size: AppDimensions.iconL),
              const SizedBox(width: AppDimensions.paddingM),
              Expanded(
                child: Text(
                  label,
                  style: textTheme.titleSmall?.copyWith(color: color),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
