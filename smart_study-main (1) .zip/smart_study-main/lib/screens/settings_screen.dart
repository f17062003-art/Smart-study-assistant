import 'package:flutter/material.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final DatabaseService _databaseService = DatabaseService();

  String _themeMode = 'system';
  int _documentCount = 0;
  int _noteCount = 0;
  int _bookCount = 0;

  @override
  void initState() {
    super.initState();
    _databaseService.addListener(_onDataChanged);
    _loadSettings();
  }

  @override
  void dispose() {
    _databaseService.removeListener(_onDataChanged);
    super.dispose();
  }

  void _onDataChanged() {
    if (mounted) _loadSettings();
  }

  Future<void> _loadSettings() async {
    _themeMode = AppSettings.stringFromThemeMode(
      AppSettings.instance.themeMode.value,
    );
    _documentCount = _databaseService.getDocumentCount();
    _noteCount = _databaseService.getNoteCount();
    _bookCount = _databaseService.getBookCount();
    setState(() {});
  }

  Future<void> _clearAllData() async {
    final scheme = Theme.of(context).colorScheme;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear all data?'),
        content: const Text(
          'This permanently deletes all documents, notes and books. This '
          'cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: scheme.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _databaseService.clearAllData();
      if (mounted) SnackBarHelper.showSuccess(context, 'All data cleared');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingM),
        children: [
          _buildSectionTitle('Storage'),
          const SizedBox(height: AppDimensions.paddingS),
          _buildStorageCard(),
          const SizedBox(height: AppDimensions.paddingXL),

          _buildSectionTitle('Appearance'),
          const SizedBox(height: AppDimensions.paddingS),
          _buildDropdownCard(
            'Theme',
            _themeMode,
            const {'system': 'System', 'light': 'Light', 'dark': 'Dark'},
            (value) {
              setState(() => _themeMode = value);
              AppSettings.instance.setThemeMode(
                AppSettings.themeModeFromString(value),
              );
            },
          ),
          const SizedBox(height: AppDimensions.paddingXL),

          _buildSectionTitle('Privacy'),
          const SizedBox(height: AppDimensions.paddingS),
          _buildInfoTile(
            'On-device only',
            'Your documents, notes and books stay on this device.',
            Icons.phonelink_lock_outlined,
          ),
          const SizedBox(height: AppDimensions.paddingM),
          _buildInfoTile(
            'Secure credentials',
            'Stored in the OS keystore (Keychain / Android Keystore).',
            Icons.lock_outline,
          ),
          const SizedBox(height: AppDimensions.paddingXL),

          _buildSectionTitle('About'),
          const SizedBox(height: AppDimensions.paddingS),
          _buildInfoTile(AppStrings.appName, 'Version 1.0.0', Icons.info_outline),
          const SizedBox(height: AppDimensions.paddingM),
          _buildInfoTile(
            'ML Kit features',
            '5 on-device recognition engines',
            Icons.auto_awesome_outlined,
          ),
          const SizedBox(height: AppDimensions.paddingXL),

          _buildSectionTitle('Danger zone'),
          const SizedBox(height: AppDimensions.paddingS),
          CustomButton(
            label: 'Clear all data',
            onPressed: _clearAllData,
            icon: const Icon(Icons.delete_outline, size: AppDimensions.iconM),
            buttonStyle: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              minimumSize: const Size.fromHeight(52),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(left: AppDimensions.paddingXS),
      child: Text(
        title.toUpperCase(),
        style: Theme.of(context).textTheme.labelMedium?.copyWith(
          color: scheme.onSurfaceVariant,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.8,
        ),
      ),
    );
  }

  Widget _buildStorageCard() {
    return CustomCard(
      margin: EdgeInsets.zero,
      child: Column(
        children: [
          _buildStorageStat('Documents', _documentCount.toString()),
          const Divider(),
          _buildStorageStat('Notes', _noteCount.toString()),
          const Divider(),
          _buildStorageStat('Books', _bookCount.toString()),
        ],
      ),
    );
  }

  Widget _buildStorageStat(String label, String value) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppDimensions.paddingS),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: textTheme.bodyMedium?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
          Text(value, style: textTheme.titleMedium),
        ],
      ),
    );
  }

  Widget _buildDropdownCard(
    String label,
    String value,
    Map<String, String> options,
    ValueChanged<String> onChanged,
  ) {
    final textTheme = Theme.of(context).textTheme;
    return CustomCard(
      margin: EdgeInsets.zero,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: textTheme.bodyLarge),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              borderRadius: BorderRadius.circular(AppDimensions.borderRadiusL),
              items: options.entries
                  .map(
                    (e) => DropdownMenuItem(value: e.key, child: Text(e.value)),
                  )
                  .toList(),
              onChanged: (v) {
                if (v != null) onChanged(v);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoTile(String title, String subtitle, IconData icon) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return CustomCard(
      margin: EdgeInsets.zero,
      child: Row(
        children: [
          Icon(icon, color: scheme.primary, size: AppDimensions.iconL),
          const SizedBox(width: AppDimensions.paddingM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: textTheme.bodyLarge),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
