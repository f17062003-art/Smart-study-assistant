import 'package:flutter/material.dart';

import '../models/chat_session.dart';
import '../services/chat_history_service.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

/// Lists saved AI conversations. Tapping one pops with the selected
/// [ChatSession] so the chat screen can resume it.
class ChatHistoryScreen extends StatefulWidget {
  const ChatHistoryScreen({super.key});

  @override
  State<ChatHistoryScreen> createState() => _ChatHistoryScreenState();
}

class _ChatHistoryScreenState extends State<ChatHistoryScreen> {
  final _service = ChatHistoryService();
  List<ChatSession> _sessions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sessions = await _service.loadSessions();
    if (!mounted) return;
    setState(() {
      _sessions = sessions;
      _loading = false;
    });
  }

  Future<void> _delete(ChatSession session) async {
    await _service.deleteSession(session.id);
    if (!mounted) return;
    setState(() => _sessions.removeWhere((s) => s.id == session.id));
    SnackBarHelper.showInfo(context, 'Chat deleted');
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Chat history')),
      body: _loading
          ? const LoadingWidget()
          : _sessions.isEmpty
          ? const EmptyWidget(
              title: 'No saved chats',
              message:
                  'Conversations you have with the assistant will appear here.',
              icon: Icons.forum_outlined,
            )
          : ListView.separated(
              padding: const EdgeInsets.all(AppDimensions.paddingM),
              itemCount: _sessions.length,
              separatorBuilder: (_, _) =>
                  const SizedBox(height: AppDimensions.paddingS),
              itemBuilder: (context, i) {
                final s = _sessions[i];
                return Card(
                  margin: EdgeInsets.zero,
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: scheme.primary.withValues(alpha: 0.12),
                      child: Icon(
                        Icons.chat_bubble_outline,
                        color: scheme.primary,
                        size: AppDimensions.iconM,
                      ),
                    ),
                    title: Text(
                      s.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: textTheme.titleSmall,
                    ),
                    subtitle: Text(
                      '${DateTimeUtilities.formatRelativeTime(s.updatedAt)} · '
                      '${s.messages.length} message${s.messages.length == 1 ? '' : 's'}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: IconButton(
                      tooltip: 'Delete',
                      icon: Icon(Icons.delete_outline, color: scheme.error),
                      onPressed: () => _delete(s),
                    ),
                    onTap: () => Navigator.pop(context, s),
                  ),
                );
              },
            ),
    );
  }
}
