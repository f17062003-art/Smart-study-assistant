import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_document_scanner/google_mlkit_document_scanner.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:uuid/uuid.dart';

import '../models/index.dart';
import '../preview_screen.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class CaptureScreen extends StatefulWidget {
  final String? initialMode;

  const CaptureScreen({super.key, this.initialMode});

  @override
  State<CaptureScreen> createState() => _CaptureScreenState();
}

class _CaptureScreenState extends State<CaptureScreen>
    with WidgetsBindingObserver {
  static const _cameraModes = {'photo', 'note', 'barcode'};

  final DatabaseService _databaseService = DatabaseService();
  final MLKitService _mlKitService = MLKitService();
  final ImagePicker _imagePicker = ImagePicker();

  CameraController? _cameraController;
  List<CameraDescription>? _cameras;
  int _selectedCameraIndex = 0;
  bool _isProcessing = false;
  bool _permissionDenied = false;
  String? _selectedMode; // 'document', 'photo', 'note', 'barcode'

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (widget.initialMode != null) {
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => _enterMode(widget.initialMode!),
      );
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cameraController?.dispose();
    _mlKitService.dispose();
    super.dispose();
  }

  // Pause/resume the camera with the app lifecycle so the preview doesn't go
  // black or leak the camera when backgrounded.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final controller = _cameraController;
    if (controller == null || !controller.value.isInitialized) return;
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      controller.dispose();
      _cameraController = null;
      if (mounted) setState(() {});
    } else if (state == AppLifecycleState.resumed &&
        _cameraModes.contains(_selectedMode)) {
      _initCamera();
    }
  }

  Future<void> _enterMode(String mode) async {
    setState(() => _selectedMode = mode);
    if (mode == 'document') {
      // The ML Kit scanner is itself the capture UI — launch it directly.
      await _scanDocument();
      return;
    }
    if (_cameraModes.contains(mode)) {
      final granted = await _ensureCameraPermission();
      if (!mounted) return;
      setState(() => _permissionDenied = !granted);
      if (granted) await _initCamera();
    }
  }

  // Capture is a pushed route, so leaving any mode pops back to the caller.
  void _exitMode() {
    _cameraController?.dispose();
    _cameraController = null;
    if (mounted) Navigator.pop(context);
  }

  Future<bool> _ensureCameraPermission() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  Future<void> _initCamera() async {
    try {
      _cameras ??= await availableCameras();
      if (_cameras == null || _cameras!.isEmpty) return;
      _selectedCameraIndex = _selectedCameraIndex % _cameras!.length;
      final controller = CameraController(
        _cameras![_selectedCameraIndex],
        ResolutionPreset.high,
        enableAudio: false,
      );
      _cameraController = controller;
      await controller.initialize();
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint('Error initializing camera: $e');
    }
  }

  Future<void> _switchCamera() async {
    if (_cameras == null || _cameras!.length < 2) return;
    _selectedCameraIndex = (_selectedCameraIndex + 1) % _cameras!.length;
    await _cameraController?.dispose();
    _cameraController = null;
    if (mounted) setState(() {});
    await _initCamera();
  }

  @override
  Widget build(BuildContext context) {
    switch (_selectedMode) {
      case 'document':
        return _buildDocumentScannerMode();
      case 'photo':
        return _buildCameraMode(
          title: 'Take photo',
          controls: _photoControls(),
        );
      case 'note':
        return _buildCameraMode(
          title: 'Capture note',
          controls: _captureButton(_captureHandwrittenNote),
        );
      case 'barcode':
        return _buildCameraMode(
          title: 'Scan barcode',
          overlays: [_barcodeOverlay()],
          controls: _captureButton(_scanBarcodePhoto),
        );
      default:
        return _buildModeSelection();
    }
  }

  Widget _buildModeSelection() {
    return Scaffold(
      appBar: AppBar(title: const Text('Capture')),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingM),
        children: [
          _buildCaptureOption(
            'Scan document',
            'Digitize textbooks and printed materials',
            Icons.document_scanner_outlined,
            AppColors.primary,
            () => _enterMode('document'),
          ),
          const SizedBox(height: AppDimensions.paddingM),
          _buildCaptureOption(
            'Take photo',
            'Capture study materials with the camera',
            Icons.camera_alt_outlined,
            AppColors.secondary,
            () => _enterMode('photo'),
          ),
          const SizedBox(height: AppDimensions.paddingM),
          _buildCaptureOption(
            'Capture note',
            'Digitize handwritten notes',
            Icons.edit_note_outlined,
            AppColors.accent,
            () => _enterMode('note'),
          ),
          const SizedBox(height: AppDimensions.paddingM),
          _buildCaptureOption(
            'Scan barcode',
            'Track books by scanning the ISBN barcode',
            Icons.qr_code_2_outlined,
            AppColors.warning,
            () => _enterMode('barcode'),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentScannerMode() {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan document'),
        leading: BackButton(onPressed: _exitMode),
      ),
      body: const LoadingWidget(message: 'Opening scanner…'),
    );
  }

  Widget _buildCameraMode({
    required String title,
    required Widget controls,
    List<Widget> overlays = const [],
  }) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        leading: BackButton(onPressed: _exitMode),
      ),
      body: _buildCameraBody(controls, overlays),
    );
  }

  Widget _buildCameraBody(Widget controls, List<Widget> overlays) {
    if (_permissionDenied) return _buildPermissionDenied();
    final controller = _cameraController;
    if (controller == null || !controller.value.isInitialized) {
      return const LoadingWidget(message: 'Starting camera…');
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        CameraPreview(controller),
        ...overlays,
        Positioned(
          bottom: AppDimensions.paddingXL,
          left: 0,
          right: 0,
          child: controls,
        ),
        if (_isProcessing)
          Container(
            color: Colors.black.withValues(alpha: 0.4),
            child: const LoadingWidget(message: 'Processing…'),
          ),
      ],
    );
  }

  Widget _buildPermissionDenied() {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.paddingXL),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.no_photography_outlined,
              size: AppDimensions.iconXL,
              color: scheme.onSurfaceVariant,
            ),
            const SizedBox(height: AppDimensions.paddingM),
            Text(
              'Camera permission needed',
              textAlign: TextAlign.center,
              style: textTheme.titleMedium,
            ),
            const SizedBox(height: AppDimensions.paddingS),
            Text(
              'Allow camera access to scan and capture study materials.',
              textAlign: TextAlign.center,
              style: textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: AppDimensions.paddingL),
            FilledButton(
              onPressed: openAppSettings,
              child: const Text('Open settings'),
            ),
            TextButton(
              onPressed: () => _enterMode(_selectedMode ?? 'photo'),
              child: const Text('Try again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _barcodeOverlay() {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black.withValues(alpha: 0.4)),
        Center(
          child: Container(
            width: 260,
            height: 180,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white, width: 2),
              borderRadius: BorderRadius.circular(AppDimensions.borderRadiusL),
            ),
          ),
        ),
      ],
    );
  }

  Widget _photoControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        FloatingActionButton(
          heroTag: 'gallery',
          backgroundColor: AppColors.secondary,
          onPressed: _isProcessing ? null : _pickPhotoFromGallery,
          child: const Icon(Icons.photo_library_outlined),
        ),
        FloatingActionButton.large(
          heroTag: 'shutter',
          onPressed: _isProcessing ? null : _takePhoto,
          child: const Icon(Icons.camera),
        ),
        FloatingActionButton(
          heroTag: 'flip',
          backgroundColor: AppColors.accent,
          onPressed: (_cameras?.length ?? 0) > 1 ? _switchCamera : null,
          child: const Icon(Icons.flip_camera_ios_outlined),
        ),
      ],
    );
  }

  Widget _captureButton(VoidCallback onPressed) {
    return Center(
      child: FloatingActionButton.large(
        heroTag: 'shutter',
        onPressed: _isProcessing ? null : onPressed,
        child: const Icon(Icons.camera),
      ),
    );
  }

  Widget _buildCaptureOption(
    String title,
    String description,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    final textTheme = Theme.of(context).textTheme;
    return Material(
      color: color.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(AppDimensions.borderRadiusL),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.paddingL),
          child: Row(
            children: [
              Icon(icon, color: color, size: AppDimensions.iconXL),
              const SizedBox(width: AppDimensions.paddingL),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: textTheme.titleSmall?.copyWith(color: color),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      description,
                      style: textTheme.bodySmall?.copyWith(
                        color: color.withValues(alpha: 0.8),
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: color, size: 16),
            ],
          ),
        ),
      ),
    );
  }

  // ---- capture + processing ------------------------------------------------

  String _titleFor(String label) =>
      '$label ${DateTimeUtilities.formatDate(DateTime.now())}';

  Future<void> _scanDocument() async {
    setState(() => _isProcessing = true);
    try {
      final result = await _mlKitService.scanDocument();
      if (mounted && result != null) {
        await _processScannedDocument(result);
      }
    } catch (e) {
      if (mounted) {
        SnackBarHelper.showError(context, 'Scanner unavailable: $e');
      }
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
    // One-shot flow: close the Capture route whether saved or cancelled.
    if (mounted) _exitMode();
  }

  Future<void> _takePhoto() async {
    try {
      final photo = await _cameraController!.takePicture();
      if (mounted) await _processPhoto(photo.path);
    } catch (e) {
      if (mounted) SnackBarHelper.showError(context, 'Error taking photo: $e');
    }
  }

  Future<void> _pickPhotoFromGallery() async {
    try {
      final image = await _imagePicker.pickImage(source: ImageSource.gallery);
      if (image != null && mounted) await _processPhoto(image.path);
    } catch (e) {
      if (mounted) SnackBarHelper.showError(context, 'Error picking image: $e');
    }
  }

  Future<void> _captureHandwrittenNote() async {
    try {
      final photo = await _cameraController!.takePicture();
      if (mounted) await _processHandwrittenNote(photo.path);
    } catch (e) {
      if (mounted) {
        SnackBarHelper.showError(context, 'Error capturing note: $e');
      }
    }
  }

  Future<void> _scanBarcodePhoto() async {
    try {
      final photo = await _cameraController!.takePicture();
      if (mounted) await _processBarcodePhoto(photo.path);
    } catch (e) {
      if (mounted) {
        SnackBarHelper.showError(context, 'Error scanning barcode: $e');
      }
    }
  }

  /// Run OCR + subject categorization on the captured image.
  Future<({String text, List<String> categories, String subject})> _analyze(
    String imagePath,
  ) async {
    setState(() => _isProcessing = true);
    var text = '';
    var categories = <String>[];
    try {
      text = await _mlKitService.recognizeTextFromFile(imagePath);
      categories = await _mlKitService.categorizeDocument(imagePath);
    } catch (e) {
      debugPrint('ML Kit analysis error: $e');
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
    final subject = categories.isNotEmpty ? categories.first : 'General';
    return (text: text, categories: categories, subject: subject);
  }

  /// Analyze → let the user review / name / categorize → save.
  /// Returns true if the item was saved.
  Future<bool> _reviewAndSave({
    required String imagePath,
    required String defaultTitle,
    bool asNote = false,
    String documentType = DocumentTypes.image,
  }) async {
    final analysis = await _analyze(imagePath);
    if (!mounted) return false;

    final result = await Navigator.push<CapturePreviewResult>(
      context,
      MaterialPageRoute(
        builder: (_) => CapturePreviewScreen(
          imagePath: imagePath,
          suggestedTitle: defaultTitle,
          suggestedSubject: analysis.subject,
          extractedText: analysis.text,
        ),
      ),
    );
    if (result == null || !mounted) return false;

    setState(() => _isProcessing = true);
    try {
      final thumbnail = await _mlKitService.createThumbnail(imagePath);
      if (asNote) {
        await _databaseService.addNote(
          Note(
            noteId: const Uuid().v4(),
            title: result.title,
            content: analysis.text,
            subject: result.subject,
            noteType: NoteTypes.handwritten,
            handwritingImagePath: imagePath,
            thumbnailPath: thumbnail,
            tags: analysis.categories,
          ),
        );
      } else {
        final fileSize = await FileUtilities.getFileSize(imagePath);
        await _databaseService.addDocument(
          Document(
            documentId: const Uuid().v4(),
            title: result.title,
            subject: result.subject,
            filePath: imagePath,
            fileName: File(imagePath).uri.pathSegments.last,
            documentType: documentType,
            extractedText: analysis.text.isNotEmpty ? [analysis.text] : [],
            thumbnailPath: thumbnail,
            fileSize: fileSize,
            tags: analysis.categories,
          ),
        );
      }
      if (mounted) SnackBarHelper.showSuccess(context, 'Saved');
      return true;
    } catch (e) {
      if (mounted) {
        SnackBarHelper.showError(context, 'Error saving: $e');
      }
      return false;
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  Future<void> _processScannedDocument(DocumentScanningResult result) async {
    final images = result.images ?? <String>[];
    if (images.isEmpty) {
      if (mounted) {
        SnackBarHelper.showError(context, 'No pages were scanned');
      }
      return;
    }
    await _reviewAndSave(
      imagePath: images.first,
      defaultTitle: _titleFor('Scanned document'),
      documentType: DocumentTypes.textbook,
    );
  }

  Future<void> _processPhoto(String imagePath) async {
    final saved = await _reviewAndSave(
      imagePath: imagePath,
      defaultTitle: _titleFor('Photo'),
    );
    if (saved && mounted) _exitMode();
  }

  Future<void> _processHandwrittenNote(String imagePath) async {
    final saved = await _reviewAndSave(
      imagePath: imagePath,
      defaultTitle: _titleFor('Handwritten note'),
      asNote: true,
    );
    if (saved && mounted) _exitMode();
  }

  Future<void> _processBarcodePhoto(String imagePath) async {
    setState(() => _isProcessing = true);
    try {
      final isbn = await _mlKitService.extractISBNFromBarcode(imagePath);
      if (isbn != null && mounted) {
        _exitMode();
        Navigator.pushNamed(
          context,
          '/book_editor',
          arguments: {'isbn': isbn, 'coverImagePath': imagePath},
        );
      } else if (mounted) {
        SnackBarHelper.showError(context, 'Could not read ISBN from barcode');
      }
    } catch (e) {
      if (mounted) {
        SnackBarHelper.showError(context, 'Error scanning barcode: $e');
      }
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }
}
