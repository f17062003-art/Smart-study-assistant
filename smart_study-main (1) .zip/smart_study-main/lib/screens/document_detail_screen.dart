import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models/index.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class DocumentDetailScreen extends StatefulWidget {
  final Document document;

  const DocumentDetailScreen({super.key, required this.document});

  @override
  State<DocumentDetailScreen> createState() => _DocumentDetailScreenState();
}

class _DocumentDetailScreenState extends State<DocumentDetailScreen> {
  final DatabaseService _databaseService = DatabaseService();
  late Document _document;
  bool _isEditing = false;
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    _document = widget.document;
    _titleController = TextEditingController(text: _document.title);
    _descriptionController = TextEditingController(
      text: _document.description ?? '',
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _saveChanges() async {
    final updated = _document.copyWith(
      title: _titleController.text,
      description: _descriptionController.text,
      updatedAt: DateTime.now(),
    );
    await _databaseService.updateDocument(updated);
    if (!mounted) return;
    setState(() {
      _document = updated;
      _isEditing = false;
    });
    SnackBarHelper.showSuccess(context, 'Document updated');
  }

  Future<void> _toggleFavorite() async {
    final updated = _document.copyWith(isFavorite: !_document.isFavorite);
    await _databaseService.updateDocument(updated);
    if (mounted) setState(() => _document = updated);
  }

  Future<void> _shareDocument() async {
    final buffer = StringBuffer(_document.title);
    if (_document.subject.isNotEmpty) {
      buffer.write('\nSubject: ${_document.subject}');
    }
    final extracted = (_document.extractedText ?? const <String>[])
        .join('\n')
        .trim();
    if (extracted.isNotEmpty) buffer.write('\n\n$extracted');
    final text = buffer.toString();
    final file = File(_document.filePath);
    if (file.existsSync()) {
      await Share.shareXFiles(
        [XFile(_document.filePath)],
        text: text,
        subject: _document.title,
      );
    } else {
      await Share.share(text, subject: _document.title);
    }
  }

  Future<void> _archiveDocument() async {
    await _databaseService.updateDocument(
      _document.copyWith(isArchived: true),
    );
    if (mounted) {
      SnackBarHelper.showSuccess(context, 'Archived');
      Navigator.pop(context);
    }
  }

  Future<void> _deleteDocument() async {
    final scheme = Theme.of(context).colorScheme;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete document?'),
        content: const Text('This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: scheme.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _databaseService.deleteDocument(_document.id);
      if (mounted) {
        SnackBarHelper.showSuccess(context, 'Document deleted');
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Document'),
        actions: [
          IconButton(
            tooltip: 'Favorite',
            icon: Icon(
              _document.isFavorite ? Icons.favorite : Icons.favorite_border,
              color: AppColors.error,
            ),
            onPressed: _toggleFavorite,
          ),
          IconButton(
            tooltip: 'Share',
            icon: const Icon(Icons.share_outlined),
            onPressed: _shareDocument,
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'edit') setState(() => _isEditing = true);
              if (v == 'archive') _archiveDocument();
              if (v == 'delete') _deleteDocument();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'edit', child: Text('Edit')),
              PopupMenuItem(value: 'archive', child: Text('Archive')),
              PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingM),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildThumbnail(scheme),
            const SizedBox(height: AppDimensions.paddingXL),
            if (!_isEditing)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_document.title, style: textTheme.headlineSmall),
                  const SizedBox(height: AppDimensions.paddingM),
                  SubjectChip(subject: _document.subject),
                  if ((_document.description ?? '').isNotEmpty) ...[
                    const SizedBox(height: AppDimensions.paddingM),
                    Text(_document.description!, style: textTheme.bodyMedium),
                  ],
                ],
              )
            else
              _buildEditor(),
            const SizedBox(height: AppDimensions.paddingXL),
            _buildInfoSection('File information', [
              ('Type', _document.documentType),
              ('Created', DateTimeUtilities.formatDate(_document.createdAt)),
              (
                'Last accessed',
                _document.lastAccessedAt != null
                    ? DateTimeUtilities.formatDate(_document.lastAccessedAt!)
                    : 'Never',
              ),
              ('Access count', _document.accessCount.toString()),
            ]),
            if (_document.tags.isNotEmpty) ...[
              const SizedBox(height: AppDimensions.paddingXL),
              Text('Tags', style: textTheme.titleMedium),
              const SizedBox(height: AppDimensions.paddingM),
              Wrap(
                spacing: AppDimensions.paddingS,
                runSpacing: AppDimensions.paddingS,
                children: _document.tags
                    .map((tag) => TagChip(tag: tag))
                    .toList(),
              ),
            ],
            if (_document.extractedText != null &&
                _document.extractedText!.isNotEmpty) ...[
              const SizedBox(height: AppDimensions.paddingXL),
              Text('Extracted text', style: textTheme.titleMedium),
              const SizedBox(height: AppDimensions.paddingM),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppDimensions.paddingM),
                decoration: BoxDecoration(
                  color: scheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(
                    AppDimensions.borderRadiusL,
                  ),
                  border: Border.all(color: scheme.outlineVariant),
                ),
                child: Text(
                  _document.extractedText!.join('\n'),
                  style: textTheme.bodySmall?.copyWith(height: 1.6),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildThumbnail(ColorScheme scheme) {
    final radius = BorderRadius.circular(AppDimensions.borderRadiusL);
    Widget placeholder() => Container(
      height: 240,
      width: double.infinity,
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest,
        borderRadius: radius,
      ),
      child: Icon(
        Icons.description_outlined,
        size: AppDimensions.iconXL,
        color: scheme.onSurfaceVariant,
      ),
    );
    if (_document.thumbnailPath == null) return placeholder();
    return ClipRRect(
      borderRadius: radius,
      child: Image.file(
        File(_document.thumbnailPath!),
        height: 240,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => placeholder(),
      ),
    );
  }

  Widget _buildEditor() {
    return Column(
      children: [
        CustomTextField(label: 'Title', controller: _titleController),
        const SizedBox(height: AppDimensions.paddingM),
        CustomTextField(
          label: 'Description',
          controller: _descriptionController,
          maxLines: 3,
        ),
        const SizedBox(height: AppDimensions.paddingM),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () => setState(() => _isEditing = false),
                child: const Text('Cancel'),
              ),
            ),
            const SizedBox(width: AppDimensions.paddingM),
            Expanded(
              child: FilledButton(
                onPressed: _saveChanges,
                child: const Text('Save'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInfoSection(String title, List<(String, String)> items) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: textTheme.titleMedium),
        const SizedBox(height: AppDimensions.paddingS),
        ...items.map((item) {
          final (label, value) = item;
          return Padding(
            padding: const EdgeInsets.symmetric(
              vertical: AppDimensions.paddingS,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  label,
                  style: textTheme.bodyMedium?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                Text(value, style: textTheme.bodyMedium),
              ],
            ),
          );
        }),
      ],
    );
  }
}
