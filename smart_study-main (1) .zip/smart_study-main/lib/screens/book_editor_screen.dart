import 'dart:io';

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/index.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class BookEditorScreen extends StatefulWidget {
  final String isbn;
  final String? coverImagePath;

  const BookEditorScreen({super.key, required this.isbn, this.coverImagePath});

  @override
  State<BookEditorScreen> createState() => _BookEditorScreenState();
}

class _BookEditorScreenState extends State<BookEditorScreen> {
  final DatabaseService _databaseService = DatabaseService();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _authorController = TextEditingController();
  final TextEditingController _publisherController = TextEditingController();
  final TextEditingController _publicationDateController =
      TextEditingController();
  final TextEditingController _totalPagesController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  String _selectedSubject = 'General';
  bool _isSaving = false;

  @override
  void dispose() {
    _titleController.dispose();
    _authorController.dispose();
    _publisherController.dispose();
    _publicationDateController.dispose();
    _totalPagesController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _saveBook() async {
    final title = _titleController.text.trim().isEmpty
        ? 'Untitled Book'
        : _titleController.text.trim();
    final author = _authorController.text.trim().isEmpty
        ? 'Unknown Author'
        : _authorController.text.trim();
    final publisher = _publisherController.text.trim().isEmpty
        ? null
        : _publisherController.text.trim();
    final publicationDate = _publicationDateController.text.trim().isEmpty
        ? null
        : _publicationDateController.text.trim();
    final totalPages = int.tryParse(_totalPagesController.text) ?? 0;

    setState(() => _isSaving = true);

    final book = Book(
      bookId: const Uuid().v4(),
      title: title,
      author: author,
      isbn: widget.isbn,
      subject: _selectedSubject,
      description: _descriptionController.text.trim(),
      publisher: publisher,
      publicationDate: publicationDate,
      coverImagePath: widget.coverImagePath,
      barcodePath: widget.coverImagePath,
      tags: [_selectedSubject],
      totalPages: totalPages,
      currentPage: 0,
      readingStatus: 'unread',
    );

    await _databaseService.addBook(book);

    if (mounted) {
      SnackBarHelper.showSuccess(context, 'Book saved');
      Navigator.pushReplacementNamed(context, '/book_detail', arguments: book);
    }
    if (mounted) setState(() => _isSaving = false);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Add book')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingM),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCover(scheme),
            const SizedBox(height: AppDimensions.paddingXL),
            Text(
              'ISBN',
              style: textTheme.labelMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: AppDimensions.paddingXS),
            Text(widget.isbn, style: textTheme.titleMedium),
            const SizedBox(height: AppDimensions.paddingXL),
            CustomTextField(label: 'Title', controller: _titleController),
            const SizedBox(height: AppDimensions.paddingM),
            CustomTextField(label: 'Author', controller: _authorController),
            const SizedBox(height: AppDimensions.paddingM),
            CustomTextField(
              label: 'Publisher',
              controller: _publisherController,
            ),
            const SizedBox(height: AppDimensions.paddingM),
            CustomTextField(
              label: 'Publication date',
              controller: _publicationDateController,
            ),
            const SizedBox(height: AppDimensions.paddingM),
            CustomTextField(
              label: 'Total pages',
              controller: _totalPagesController,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: AppDimensions.paddingM),
            CustomTextField(
              label: 'Description',
              controller: _descriptionController,
              maxLines: 4,
            ),
            const SizedBox(height: AppDimensions.paddingL),
            Text(
              'Subject',
              style: textTheme.labelLarge?.copyWith(color: scheme.onSurface),
            ),
            const SizedBox(height: AppDimensions.paddingS),
            Wrap(
              spacing: AppDimensions.paddingS,
              runSpacing: AppDimensions.paddingS,
              children: AppColors.subjectColors.keys.map((subject) {
                final selected = subject == _selectedSubject;
                return ChoiceChip(
                  label: Text(subject),
                  selected: selected,
                  showCheckmark: false,
                  backgroundColor: scheme.surface,
                  selectedColor: scheme.primary,
                  side: BorderSide(
                    color: selected ? scheme.primary : scheme.outlineVariant,
                  ),
                  labelStyle: textTheme.labelLarge?.copyWith(
                    color: selected ? scheme.onPrimary : scheme.onSurface,
                  ),
                  onSelected: (_) => setState(() => _selectedSubject = subject),
                );
              }).toList(),
            ),
            const SizedBox(height: AppDimensions.paddingXL),
            SizedBox(
              width: double.infinity,
              child: CustomButton(
                label: _isSaving ? 'Saving…' : 'Save book',
                isLoading: _isSaving,
                onPressed: () {
                  if (!_isSaving) _saveBook();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCover(ColorScheme scheme) {
    final radius = BorderRadius.circular(AppDimensions.borderRadiusL);
    Widget placeholder() => Container(
      height: 220,
      width: double.infinity,
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest,
        borderRadius: radius,
      ),
      child: Icon(
        Icons.menu_book_outlined,
        size: AppDimensions.iconXL,
        color: scheme.onSurfaceVariant,
      ),
    );
    if (widget.coverImagePath == null) return placeholder();
    return ClipRRect(
      borderRadius: radius,
      child: Image.file(
        File(widget.coverImagePath!),
        height: 220,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => placeholder(),
      ),
    );
  }
}
