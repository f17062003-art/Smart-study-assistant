import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../models/index.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class NoteDetailScreen extends StatefulWidget {
  final Note note;

  const NoteDetailScreen({super.key, required this.note});

  @override
  State<NoteDetailScreen> createState() => _NoteDetailScreenState();
}

class _NoteDetailScreenState extends State<NoteDetailScreen> {
  final DatabaseService _databaseService = DatabaseService();
  late Note _note;
  bool _isEditing = false;
  late TextEditingController _titleController;
  late TextEditingController _contentController;

  @override
  void initState() {
    super.initState();
    _note = widget.note;
    _titleController = TextEditingController(text: _note.title);
    _contentController = TextEditingController(text: _note.content);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  Future<void> _saveChanges() async {
    final updated = _note.copyWith(
      title: _titleController.text,
      content: _contentController.text,
      updatedAt: DateTime.now(),
    );
    await _databaseService.updateNote(updated);
    if (!mounted) return;
    setState(() {
      _note = updated;
      _isEditing = false;
    });
    SnackBarHelper.showSuccess(context, 'Note updated');
  }

  Future<void> _toggleFavorite() async {
    final updated = _note.copyWith(isFavorite: !_note.isFavorite);
    await _databaseService.updateNote(updated);
    if (mounted) setState(() => _note = updated);
  }

  Future<void> _shareNote() async {
    final buffer = StringBuffer(_note.title);
    if (_note.subject.isNotEmpty) buffer.write('\nSubject: ${_note.subject}');
    if (_note.content.trim().isNotEmpty) {
      buffer.write('\n\n${_note.content.trim()}');
    }
    await Share.share(buffer.toString(), subject: _note.title);
  }

  Future<void> _archiveNote() async {
    await _databaseService.updateNote(_note.copyWith(isArchived: true));
    if (mounted) {
      SnackBarHelper.showSuccess(context, 'Archived');
      Navigator.pop(context);
    }
  }

  Future<void> _deleteNote() async {
    final scheme = Theme.of(context).colorScheme;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete note?'),
        content: const Text('This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: scheme.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _databaseService.deleteNote(_note.id);
      if (mounted) {
        SnackBarHelper.showSuccess(context, 'Note deleted');
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Note'),
        actions: [
          IconButton(
            tooltip: 'Favorite',
            icon: Icon(
              _note.isFavorite ? Icons.favorite : Icons.favorite_border,
              color: AppColors.error,
            ),
            onPressed: _toggleFavorite,
          ),
          IconButton(
            tooltip: 'Share',
            icon: const Icon(Icons.share_outlined),
            onPressed: _shareNote,
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'edit') setState(() => _isEditing = true);
              if (v == 'archive') _archiveNote();
              if (v == 'delete') _deleteNote();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'edit', child: Text('Edit')),
              PopupMenuItem(value: 'archive', child: Text('Archive')),
              PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingM),
        child: _isEditing ? _buildEditor() : _buildContent(scheme, textTheme),
      ),
    );
  }

  Widget _buildContent(ColorScheme scheme, TextTheme textTheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(_note.title, style: textTheme.headlineSmall),
        const SizedBox(height: AppDimensions.paddingM),
        Row(
          children: [
            SubjectChip(subject: _note.subject),
            const SizedBox(width: AppDimensions.paddingM),
            Text(
              DateTimeUtilities.formatDateTime(_note.createdAt),
              style: textTheme.bodySmall?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
        const SizedBox(height: AppDimensions.paddingXL),
        Text('Content', style: textTheme.titleMedium),
        const SizedBox(height: AppDimensions.paddingM),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(AppDimensions.paddingM),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(AppDimensions.borderRadiusL),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Text(
            _note.content.isEmpty ? 'No content' : _note.content,
            style: textTheme.bodyMedium?.copyWith(height: 1.6),
          ),
        ),
        if (_note.tags.isNotEmpty) ...[
          const SizedBox(height: AppDimensions.paddingXL),
          Text('Tags', style: textTheme.titleMedium),
          const SizedBox(height: AppDimensions.paddingM),
          Wrap(
            spacing: AppDimensions.paddingS,
            runSpacing: AppDimensions.paddingS,
            children: _note.tags.map((tag) => TagChip(tag: tag)).toList(),
          ),
        ],
      ],
    );
  }

  Widget _buildEditor() {
    return Column(
      children: [
        CustomTextField(label: 'Title', controller: _titleController),
        const SizedBox(height: AppDimensions.paddingM),
        CustomTextField(
          label: 'Content',
          controller: _contentController,
          maxLines: 10,
        ),
        const SizedBox(height: AppDimensions.paddingM),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () => setState(() => _isEditing = false),
                child: const Text('Cancel'),
              ),
            ),
            const SizedBox(width: AppDimensions.paddingM),
            Expanded(
              child: FilledButton(
                onPressed: _saveChanges,
                child: const Text('Save'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
