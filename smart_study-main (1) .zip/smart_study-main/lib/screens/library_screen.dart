import 'package:flutter/material.dart';
import '../models/index.dart';
import '../services/index.dart';
import '../utils/index.dart';
import '../widgets/index.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final DatabaseService _databaseService = DatabaseService();
  final StorageService _storageService = StorageService();

  List<Subject> _subjects = [];
  List<Document> _documents = [];
  List<Note> _notes = [];
  List<Book> _books = [];

  String? _selectedSubject;
  String _viewMode = 'grid'; // 'grid' or 'list'
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _databaseService.addListener(_onDataChanged);
    _loadData();
  }

  @override
  void dispose() {
    _databaseService.removeListener(_onDataChanged);
    super.dispose();
  }

  void _onDataChanged() {
    if (mounted) _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    _subjects = _databaseService.getAllSubjects();
    _documents = _databaseService
        .getAllDocuments()
        .where((doc) => !doc.isArchived)
        .toList();
    _notes = _databaseService
        .getAllNotes()
        .where((note) => !note.isArchived)
        .toList();
    _books = _databaseService
        .getAllBooks()
        .where((book) => !book.isArchived)
        .toList();

    _viewMode = _storageService.getLibraryViewMode();

    setState(() => _isLoading = false);
  }

  List<Document> _getFilteredDocuments() {
    if (_selectedSubject == null) return _documents;
    return _documents.where((doc) => doc.subject == _selectedSubject).toList();
  }

  List<Note> _getFilteredNotes() {
    if (_selectedSubject == null) return _notes;
    return _notes.where((note) => note.subject == _selectedSubject).toList();
  }

  List<Book> _getFilteredBooks() {
    if (_selectedSubject == null) return _books;
    return _books.where((book) => book.subject == _selectedSubject).toList();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Library'),
          actions: [
            IconButton(
              tooltip: _viewMode == 'grid' ? 'List view' : 'Grid view',
              icon: Icon(
                _viewMode == 'grid'
                    ? Icons.view_list_outlined
                    : Icons.grid_view_outlined,
              ),
              onPressed: () {
                setState(() {
                  _viewMode = _viewMode == 'grid' ? 'list' : 'grid';
                });
                _storageService.setLibraryViewMode(_viewMode);
              },
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(56),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppDimensions.paddingM,
                vertical: AppDimensions.paddingS,
              ),
              child: TabBar(
                labelColor: scheme.primary,
                unselectedLabelColor: scheme.onSurfaceVariant,
                dividerColor: Colors.transparent,
                indicatorSize: TabBarIndicatorSize.tab,
                indicator: BoxDecoration(
                  color: scheme.primary.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(
                    AppDimensions.borderRadiusL,
                  ),
                ),
                tabs: [
                  Tab(text: 'Documents (${_documents.length})'),
                  Tab(text: 'Notes (${_notes.length})'),
                  Tab(text: 'Books (${_books.length})'),
                ],
              ),
            ),
          ),
        ),
        body: _isLoading
            ? const LoadingWidget()
            : Column(
                children: [
                  _buildSubjectFilter(),
                  Expanded(
                    child: TabBarView(
                      children: [
                        _buildDocumentsView(),
                        _buildNotesView(),
                        _buildBooksView(),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildSubjectFilter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppDimensions.paddingM,
        AppDimensions.paddingM,
        AppDimensions.paddingM,
        AppDimensions.paddingXS,
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildSubjectChip(null, 'All'),
            ..._subjects.map((s) => _buildSubjectChip(s.name, s.name)),
          ],
        ),
      ),
    );
  }

  Widget _buildSubjectChip(String? subject, String label) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final isSelected = _selectedSubject == subject;
    return Padding(
      padding: const EdgeInsets.only(right: AppDimensions.paddingS),
      child: Material(
        color: isSelected ? scheme.primary : scheme.surface,
        clipBehavior: Clip.antiAlias,
        shape: StadiumBorder(
          side: BorderSide(
            color: isSelected ? scheme.primary : scheme.outlineVariant,
          ),
        ),
        child: InkWell(
          onTap: () => setState(() => _selectedSubject = subject),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppDimensions.paddingM,
              vertical: AppDimensions.paddingXS,
            ),
            child: Text(
              label,
              style: textTheme.labelMedium?.copyWith(
                color: isSelected ? scheme.onPrimary : scheme.onSurfaceVariant,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDocumentsView() {
    final docs = _getFilteredDocuments();

    if (docs.isEmpty) {
      return const EmptyWidget(
        title: 'No Documents',
        message: 'Start by scanning a document or textbook',
        icon: Icons.description_outlined,
      );
    }

    return _gridOrList(
      itemCount: docs.length,
      grid: _viewMode == 'grid',
      builder: (context, index) => DocumentCard(
        document: docs[index],
        onTap: () => _openDocument(docs[index]),
        onToggleFavorite: () => _toggleDocumentFavorite(docs[index]),
        onDelete: () => _deleteDocument(docs[index]),
      ),
    );
  }

  Widget _buildNotesView() {
    final notes = _getFilteredNotes();

    if (notes.isEmpty) {
      return const EmptyWidget(
        title: 'No Notes',
        message: 'Create a new note to get started',
        icon: Icons.sticky_note_2_outlined,
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(AppDimensions.paddingM),
      itemCount: notes.length,
      separatorBuilder: (_, _) =>
          const SizedBox(height: AppDimensions.paddingM),
      itemBuilder: (context, index) => NoteCard(
        note: notes[index],
        onTap: () => _openNote(notes[index]),
        onToggleFavorite: () => _toggleNoteFavorite(notes[index]),
        onDelete: () => _deleteNote(notes[index]),
      ),
    );
  }

  Widget _buildBooksView() {
    final books = _getFilteredBooks();

    if (books.isEmpty) {
      return const EmptyWidget(
        title: 'No Books',
        message: 'Scan a barcode to add a book',
        icon: Icons.menu_book_outlined,
      );
    }

    return _gridOrList(
      itemCount: books.length,
      grid: _viewMode == 'grid',
      builder: (context, index) => BookCard(
        book: books[index],
        onTap: () => _openBook(books[index]),
        onToggleFavorite: () => _toggleBookFavorite(books[index]),
        onDelete: () => _deleteBook(books[index]),
      ),
    );
  }

  Widget _gridOrList({
    required int itemCount,
    required bool grid,
    required Widget Function(BuildContext, int) builder,
  }) {
    if (grid) {
      return GridView.builder(
        padding: const EdgeInsets.all(AppDimensions.paddingM),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: AppDimensions.paddingM,
          crossAxisSpacing: AppDimensions.paddingM,
          childAspectRatio: 0.68,
        ),
        itemCount: itemCount,
        itemBuilder: builder,
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppDimensions.paddingM),
      itemCount: itemCount,
      separatorBuilder: (_, _) =>
          const SizedBox(height: AppDimensions.paddingM),
      itemBuilder: builder,
    );
  }

  Future<void> _openDocument(Document document) async {
    final updated = document.copyWith(
      accessCount: document.accessCount + 1,
      lastAccessedAt: DateTime.now(),
    );
    await _databaseService.updateDocument(updated);

    if (mounted) {
      Navigator.pushNamed(context, '/document_detail', arguments: updated);
    }
  }

  Future<void> _openNote(Note note) async {
    final updated = note.copyWith(
      accessCount: note.accessCount + 1,
      lastAccessedAt: DateTime.now(),
    );
    await _databaseService.updateNote(updated);

    if (mounted) {
      Navigator.pushNamed(context, '/note_detail', arguments: updated);
    }
  }

  Future<void> _openBook(Book book) async {
    final updated = book.copyWith(
      accessCount: book.accessCount + 1,
      lastAccessedAt: DateTime.now(),
    );
    await _databaseService.updateBook(updated);

    if (mounted) {
      Navigator.pushNamed(context, '/book_detail', arguments: updated);
    }
  }

  Future<void> _toggleDocumentFavorite(Document document) async {
    await _databaseService.updateDocument(
      document.copyWith(isFavorite: !document.isFavorite),
    );
  }

  Future<void> _toggleNoteFavorite(Note note) async {
    await _databaseService.updateNote(
      note.copyWith(isFavorite: !note.isFavorite),
    );
  }

  Future<void> _toggleBookFavorite(Book book) async {
    await _databaseService.updateBook(
      book.copyWith(isFavorite: !book.isFavorite),
    );
  }

  Future<void> _deleteDocument(Document document) async {
    await _databaseService.deleteDocument(document.id);
    if (!mounted) return;
    SnackBarHelper.showUndo(
      context,
      'Document deleted',
      () => _databaseService.addDocument(document),
    );
  }

  Future<void> _deleteNote(Note note) async {
    await _databaseService.deleteNote(note.id);
    if (!mounted) return;
    SnackBarHelper.showUndo(
      context,
      'Note deleted',
      () => _databaseService.addNote(note),
    );
  }

  Future<void> _deleteBook(Book book) async {
    await _databaseService.deleteBook(book.id);
    if (!mounted) return;
    SnackBarHelper.showUndo(
      context,
      'Book deleted',
      () => _databaseService.addBook(book),
    );
  }
}
