import 'dart:io';

import 'package:flutter/material.dart';

import 'utils/index.dart';
import 'widgets/index.dart';

/// Result returned from [CapturePreviewScreen] when the user confirms a capture.
class CapturePreviewResult {
  final String title;
  final String subject;

  const CapturePreviewResult({required this.title, required this.subject});
}

/// Review screen shown after a capture: preview the image, then name and
/// categorize it before it's saved. Returns a [CapturePreviewResult] on save,
/// or null if the user backs out (retake).
class CapturePreviewScreen extends StatefulWidget {
  final String imagePath;
  final String suggestedTitle;
  final String suggestedSubject;
  final String? extractedText;

  const CapturePreviewScreen({
    super.key,
    required this.imagePath,
    required this.suggestedTitle,
    required this.suggestedSubject,
    this.extractedText,
  });

  @override
  State<CapturePreviewScreen> createState() => _CapturePreviewScreenState();
}

class _CapturePreviewScreenState extends State<CapturePreviewScreen> {
  late final TextEditingController _titleController;
  late String _subject;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.suggestedTitle);
    _subject = widget.suggestedSubject;
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  void _save() {
    final title = _titleController.text.trim().isEmpty
        ? widget.suggestedTitle
        : _titleController.text.trim();
    Navigator.pop(
      context,
      CapturePreviewResult(title: title, subject: _subject),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final subjects = <String>{
      ...DefaultSubjects.subjects,
      'General',
      widget.suggestedSubject,
    }.toList();
    final extracted = (widget.extractedText ?? '').trim();

    return Scaffold(
      appBar: AppBar(title: const Text('Review')),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingM),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(AppDimensions.borderRadiusL),
            child: Image.file(
              File(widget.imagePath),
              height: 260,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, _, _) => Container(
                height: 260,
                color: scheme.surfaceContainerHighest,
                child: Icon(
                  Icons.broken_image_outlined,
                  size: AppDimensions.iconXL,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
          ),
          const SizedBox(height: AppDimensions.paddingXL),
          CustomTextField(label: 'Title', controller: _titleController),
          const SizedBox(height: AppDimensions.paddingL),
          Text('Subject', style: textTheme.labelLarge),
          const SizedBox(height: AppDimensions.paddingS),
          Wrap(
            spacing: AppDimensions.paddingS,
            runSpacing: AppDimensions.paddingS,
            children: subjects.map((s) {
              final selected = s == _subject;
              return ChoiceChip(
                label: Text(s),
                selected: selected,
                showCheckmark: false,
                backgroundColor: scheme.surface,
                selectedColor: scheme.primary,
                side: BorderSide(
                  color: selected ? scheme.primary : scheme.outlineVariant,
                ),
                labelStyle: textTheme.labelLarge?.copyWith(
                  color: selected ? scheme.onPrimary : scheme.onSurface,
                ),
                onSelected: (_) => setState(() => _subject = s),
              );
            }).toList(),
          ),
          if (extracted.isNotEmpty) ...[
            const SizedBox(height: AppDimensions.paddingL),
            Text('Extracted text', style: textTheme.labelLarge),
            const SizedBox(height: AppDimensions.paddingS),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(AppDimensions.paddingM),
              decoration: BoxDecoration(
                color: scheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(
                  AppDimensions.borderRadiusL,
                ),
                border: Border.all(color: scheme.outlineVariant),
              ),
              child: Text(
                extracted,
                style: textTheme.bodySmall?.copyWith(height: 1.5),
              ),
            ),
          ],
          const SizedBox(height: AppDimensions.paddingXL),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Retake'),
                ),
              ),
              const SizedBox(width: AppDimensions.paddingM),
              Expanded(
                child: FilledButton(
                  onPressed: _save,
                  child: const Text('Save'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
