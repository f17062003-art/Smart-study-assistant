import 'package:flutter/material.dart';

import 'models/index.dart';
import 'screens/book_detail_screen.dart';
import 'screens/document_detail_screen.dart';
import 'screens/index.dart';
import 'screens/chat_screen.dart';
import 'screens/note_detail_screen.dart';
import 'services/index.dart';
import 'utils/index.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize services
  final databaseService = DatabaseService();
  final storageService = StorageService();

  await databaseService.initialize();
  await storageService.initialize();

  // Load the persisted theme so the app starts in the user's chosen mode.
  AppSettings.instance.load();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: AppSettings.instance.themeMode,
      builder: (context, themeMode, _) => MaterialApp(
        title: AppStrings.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        themeMode: themeMode,
        home: const MainScreen(),
        routes: {
          '/home': (_) => const HomeScreen(),
          '/library': (_) => const LibraryScreen(),
          '/capture': (_) => const CaptureScreen(),
          '/capture_document': (_) =>
              const CaptureScreen(initialMode: 'document'),
          '/capture_photo': (_) => const CaptureScreen(initialMode: 'photo'),
          '/note_editor': (_) => const CaptureScreen(initialMode: 'note'),
          '/barcode': (_) => const CaptureScreen(initialMode: 'barcode'),
          '/search': (_) => const SearchScreen(),
          '/settings': (_) => const SettingsScreen(),
          '/document_detail': (context) {
            final args = ModalRoute.of(context)!.settings.arguments as Document;
            return DocumentDetailScreen(document: args);
          },
          '/note_detail': (context) {
            final args = ModalRoute.of(context)!.settings.arguments as Note;
            return NoteDetailScreen(note: args);
          },
          '/book_detail': (context) {
            final args = ModalRoute.of(context)!.settings.arguments as Book;
            return BookDetailScreen(book: args);
          },
          '/book_editor': (context) {
            final args =
                ModalRoute.of(context)!.settings.arguments
                    as Map<String, dynamic>;
            return BookEditorScreen(
              isbn: args['isbn'] as String,
              coverImagePath: args['coverImagePath'] as String?,
            );
          },
          '/ai_chat': (_) => const ChatScreen(),
        },
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  // Capture (index 2) is an action that opens a bottom sheet, not a page, so
  // the IndexedStack only hosts the four real tabs. Tabs are built lazily on
  // first visit and kept alive to preserve their state.
  static const _captureIndex = 2;
  int _selectedIndex = 0;
  final Set<int> _visited = {0};

  Widget _screenAt(int index) {
    switch (index) {
      case 0:
        return const HomeScreen();
      case 1:
        return const LibraryScreen();
      case 3:
        return const SearchScreen();
      case 4:
        return const SettingsScreen();
      default:
        return const SizedBox.shrink();
    }
  }

  void _onDestinationSelected(int index) {
    if (index == _captureIndex) {
      _openCaptureSheet();
      return;
    }
    setState(() {
      _selectedIndex = index;
      _visited.add(index);
    });
  }

  Future<void> _openCaptureSheet() async {
    final mode = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: AppDimensions.paddingM),
              child: Text(
                'Capture',
                textAlign: TextAlign.center,
                style: Theme.of(sheetContext).textTheme.titleMedium,
              ),
            ),
            _captureOption(
              sheetContext,
              'Scan document',
              'Digitize textbooks & printed pages',
              Icons.document_scanner_outlined,
              AppColors.primary,
              'document',
            ),
            _captureOption(
              sheetContext,
              'Take photo',
              'Snap study materials',
              Icons.camera_alt_outlined,
              AppColors.secondary,
              'photo',
            ),
            _captureOption(
              sheetContext,
              'Capture note',
              'Digitize handwritten notes',
              Icons.edit_note_outlined,
              AppColors.accent,
              'note',
            ),
            _captureOption(
              sheetContext,
              'Scan barcode',
              'Add a book by its ISBN',
              Icons.qr_code_2_outlined,
              AppColors.info,
              'barcode',
            ),
            const SizedBox(height: AppDimensions.paddingM),
          ],
        ),
      ),
    );
    if (mode == null || !mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => CaptureScreen(initialMode: mode)),
    );
  }

  Widget _captureOption(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
    Color color,
    String mode,
  ) {
    final textTheme = Theme.of(context).textTheme;
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimensions.paddingM,
        vertical: AppDimensions.paddingXS,
      ),
      child: Material(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusL),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.pop(context, mode),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppDimensions.paddingM,
              vertical: AppDimensions.paddingS,
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(AppDimensions.paddingS),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.16),
                    borderRadius: BorderRadius.circular(
                      AppDimensions.borderRadiusM,
                    ),
                  ),
                  child: Icon(icon, color: color, size: AppDimensions.iconM),
                ),
                const SizedBox(width: AppDimensions.paddingL),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: textTheme.titleSmall?.copyWith(
                          color: scheme.onSurface,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: textTheme.bodySmall?.copyWith(
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: color, size: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: List.generate(
          5,
          (index) => _visited.contains(index)
              ? _screenAt(index)
              : const SizedBox.shrink(),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: _onDestinationSelected,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.library_books_outlined),
            selectedIcon: Icon(Icons.library_books),
            label: 'Library',
          ),
          NavigationDestination(
            icon: Icon(Icons.add_circle_outline),
            selectedIcon: Icon(Icons.add_circle),
            label: 'Capture',
          ),
          NavigationDestination(
            icon: Icon(Icons.search_outlined),
            selectedIcon: Icon(Icons.search),
            label: 'Search',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
