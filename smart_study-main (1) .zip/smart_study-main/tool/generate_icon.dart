// Generates the app launcher icon assets using the `image` package.
// Run: dart run tool/generate_icon.dart
import 'dart:io';

import 'package:image/image.dart' as img;

const _size = 1024;
const _indigo = [0x4F, 0x46, 0xE5];
const _teal = [0x14, 0xB8, 0xA6];

img.ColorRgb8 _lerp(List<int> a, List<int> b, double t) => img.ColorRgb8(
  (a[0] + (b[0] - a[0]) * t).round(),
  (a[1] + (b[1] - a[1]) * t).round(),
  (a[2] + (b[2] - a[2]) * t).round(),
);

void _gradient(img.Image image) {
  for (var y = 0; y < _size; y++) {
    for (var x = 0; x < _size; x++) {
      final t = ((x + y) / (2 * (_size - 1))).clamp(0.0, 1.0);
      image.setPixel(x, y, _lerp(_indigo, _teal, t));
    }
  }
}

/// Draws a clean white "document" mark (page + 3 text lines), [scale]d around
/// the centre so it can sit inside the Android adaptive-icon safe zone.
void _doc(img.Image image, {double scale = 1.0}) {
  final s = _size.toDouble();
  final c = s / 2;
  int sx(double f) => (c + (f * s - c) * scale).round();
  int sy(double f) => (c + (f * s - c) * scale).round();
  final white = img.ColorRgba8(255, 255, 255, 255);
  final ink = img.ColorRgba8(0x4F, 0x46, 0xE5, 120);

  img.fillRect(
    image,
    x1: sx(0.30),
    y1: sy(0.24),
    x2: sx(0.70),
    y2: sy(0.76),
    color: white,
    radius: (0.05 * s * scale).round(),
  );
  for (var i = 0; i < 3; i++) {
    final ly = 0.37 + i * 0.11;
    img.fillRect(
      image,
      x1: sx(0.37),
      y1: sy(ly),
      x2: sx(i == 2 ? 0.55 : 0.63),
      y2: sy(ly + 0.035),
      color: ink,
      radius: (0.015 * s * scale).round(),
    );
  }
}

void main() {
  Directory('assets').createSync(recursive: true);

  // Full icon (iOS + legacy Android): gradient + document.
  final icon = img.Image(width: _size, height: _size, numChannels: 4);
  _gradient(icon);
  _doc(icon);
  File('assets/icon.png').writeAsBytesSync(img.encodePng(icon));

  // Android adaptive background: gradient only.
  final bg = img.Image(width: _size, height: _size, numChannels: 4);
  _gradient(bg);
  File('assets/icon_bg.png').writeAsBytesSync(img.encodePng(bg));

  // Android adaptive foreground: document on transparent, inside the safe zone.
  final fg = img.Image(width: _size, height: _size, numChannels: 4);
  img.fill(fg, color: img.ColorRgba8(0, 0, 0, 0));
  _doc(fg, scale: 0.62);
  File('assets/icon_fg.png').writeAsBytesSync(img.encodePng(fg));

  stdout.writeln('Generated assets/icon.png, icon_bg.png, icon_fg.png');
}
