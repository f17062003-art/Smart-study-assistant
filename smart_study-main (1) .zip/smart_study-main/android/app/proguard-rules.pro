# ML Kit rules - Keep all ML Kit classes
-keep class com.google.mlkit.** { *; }
-keepclassmembers class com.google.mlkit.** { *; }

# Suppress warnings for language-specific text recognizers (optional packages)
-dontwarn com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions$Builder
-dontwarn com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions$Builder
-dontwarn com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions$Builder
-dontwarn com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions$Builder
-dontwarn com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions

# Keep all language packages that exist
-keep class com.google.mlkit.vision.text.** { *; }

# Keep all native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Google Play Services
-keep class com.google.android.gms.** { *; }
-keep interface com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**

# Firebase
-keep class com.google.firebase.** { *; }
-keep interface com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# TensorFlow Lite (used by ML Kit)
-keep class org.tensorflow.** { *; }
-keep class org.tensorflow.lite.** { *; }
-dontwarn org.tensorflow.**

# Protocol Buffers (used by ML Kit and other libraries)
-keep class com.google.protobuf.** { *; }
-keep interface com.google.protobuf.** { *; }

# GoogleAI/Gemini API
-keep class com.google.ai.client.generativeai.** { *; }
-keep interface com.google.ai.client.generativeai.** { *; }
-dontwarn com.google.ai.client.generativeai.**

# Keep enum values and valueOf() methods
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Keep parcelable implementations
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Keep Serializable implementations
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Preserve line numbers for debugging
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Keep annotations
-keepattributes *Annotation*
-keepattributes InnerClasses

# ObjectBox (Database)
-keep class io.objectbox.** { *; }
-keep interface io.objectbox.** { *; }
-keep class * extends io.objectbox.BoxStore

# Shared Preferences & Security
-keep class androidx.security.crypto.** { *; }
-keep class android.security.** { *; }

# Image library (Glide, Image Picker, etc.)
-keep class com.bumptech.glide.** { *; }
-keep class com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool { *; }
-keep class android.graphics.** { *; }

# UUID
-keep class java.util.UUID { *; }

# Collection types
-keep class java.util.** { *; }
-keep interface java.util.** { *; }

# Kotlin
-keep class kotlin.** { *; }
-keep interface kotlin.** { *; }
-keep class kotlinx.** { *; }
-keepclassmembers class * {
    ** CREATOR;
}

# Suppress warnings for unavailable classes
-dontwarn java.**
-dontwarn javax.**
-dontwarn com.fasterxml.**
-dontwarn org.apache.**

# Logging - only for debugging, can be removed after release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}

