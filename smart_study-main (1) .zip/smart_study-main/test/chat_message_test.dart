import 'package:flutter_test/flutter_test.dart';
import 'package:smart_study_assistant/models/chat_message.dart';

void main() {
  group('ChatMessage', () {
    test('toJson / fromJson round-trips every field', () {
      final original = ChatMessage(
        id: 'abc-123',
        text: 'Hello there',
        isUser: true,
        imageUrl: '/tmp/render.png',
        createdAt: DateTime(2024, 1, 2, 9, 30, 15),
      );

      final restored = ChatMessage.fromJson(original.toJson());

      expect(restored.id, original.id);
      expect(restored.text, original.text);
      expect(restored.isUser, original.isUser);
      expect(restored.imageUrl, original.imageUrl);
      expect(restored.createdAt, original.createdAt);
    });

    test('round-trips a null imageUrl', () {
      final original = ChatMessage(
        id: 'no-image',
        text: 'Just text',
        isUser: false,
        createdAt: DateTime(2023, 12, 31),
      );

      final restored = ChatMessage.fromJson(original.toJson());

      expect(restored.imageUrl, isNull);
      expect(restored.isUser, isFalse);
    });

    test('defaults createdAt to now when omitted', () {
      final before = DateTime.now();
      final message = ChatMessage(id: '1', text: 'hi', isUser: true);
      final after = DateTime.now();

      expect(
        message.createdAt.isBefore(before.subtract(const Duration(seconds: 1))),
        isFalse,
      );
      expect(
        message.createdAt.isAfter(after.add(const Duration(seconds: 1))),
        isFalse,
      );
    });

    test('copyWith overrides only the provided fields', () {
      final original = ChatMessage(
        id: 'keep-id',
        text: 'original',
        isUser: false,
        createdAt: DateTime(2024, 5, 1),
      );

      final updated = original.copyWith(text: 'edited', isUser: true);

      expect(updated.id, 'keep-id');
      expect(updated.text, 'edited');
      expect(updated.isUser, isTrue);
      expect(updated.createdAt, original.createdAt);
    });
  });
}
