import 'package:flutter_test/flutter_test.dart';
import 'package:smart_study_assistant/utils/utilities.dart';

void main() {
  group('FileUtilities.formatFileSize', () {
    test('handles zero and negative byte counts', () {
      expect(FileUtilities.formatFileSize(0), '0 B');
      expect(FileUtilities.formatFileSize(-10), '0 B');
    });

    test('formats bytes without decimals', () {
      expect(FileUtilities.formatFileSize(512), '512 B');
    });

    test('formats kilobytes, megabytes and gigabytes with one decimal', () {
      expect(FileUtilities.formatFileSize(1024), '1.0 KB');
      expect(FileUtilities.formatFileSize(1536), '1.5 KB');
      expect(FileUtilities.formatFileSize(1048576), '1.0 MB');
      expect(FileUtilities.formatFileSize(1073741824), '1.0 GB');
    });
  });

  group('FileUtilities extension helpers', () {
    test('getFileExtension lowercases and takes the last segment', () {
      expect(FileUtilities.getFileExtension('photo.JPG'), 'jpg');
      expect(FileUtilities.getFileExtension('archive.tar.gz'), 'gz');
      expect(FileUtilities.getFileExtension('document.pdf'), 'pdf');
    });

    test('getFileExtension returns empty when there is no dot', () {
      expect(FileUtilities.getFileExtension('README'), '');
    });

    test('getFileNameWithoutExtension strips the trailing extension', () {
      expect(FileUtilities.getFileNameWithoutExtension('photo.jpg'), 'photo');
      expect(
        FileUtilities.getFileNameWithoutExtension('archive.tar.gz'),
        'archive.tar',
      );
      expect(FileUtilities.getFileNameWithoutExtension('README'), 'README');
    });
  });

  group('ValidationUtilities', () {
    test('isValidEmail accepts well-formed addresses', () {
      expect(ValidationUtilities.isValidEmail('test@example.com'), isTrue);
      expect(
        ValidationUtilities.isValidEmail('user.name+tag@sub.domain.io'),
        isTrue,
      );
    });

    test('isValidEmail rejects malformed addresses', () {
      expect(ValidationUtilities.isValidEmail('plainaddress'), isFalse);
      expect(ValidationUtilities.isValidEmail('missingatsign.com'), isFalse);
      expect(ValidationUtilities.isValidEmail('@no-local.com'), isFalse);
    });

    test('isValidISBN accepts 10- and 13-digit numbers, with separators', () {
      expect(ValidationUtilities.isValidISBN('0306406152'), isTrue);
      expect(ValidationUtilities.isValidISBN('9783161484100'), isTrue);
      expect(ValidationUtilities.isValidISBN('978-3-16-148410-0'), isTrue);
    });

    test('isValidISBN rejects wrong lengths or non-digits', () {
      expect(ValidationUtilities.isValidISBN('123'), isFalse);
      expect(ValidationUtilities.isValidISBN('12345678AB'), isFalse);
    });

    test('isValidBarcode requires a non-empty digit string', () {
      expect(ValidationUtilities.isValidBarcode('012345678905'), isTrue);
      expect(ValidationUtilities.isValidBarcode(''), isFalse);
      expect(ValidationUtilities.isValidBarcode('12a45'), isFalse);
    });

    test('isValidTitle / isValidSubject enforce minimum lengths', () {
      expect(ValidationUtilities.isValidTitle('Math'), isTrue);
      expect(ValidationUtilities.isValidTitle('Hi'), isFalse);
      expect(ValidationUtilities.isValidSubject('Bio'), isTrue);
      expect(ValidationUtilities.isValidSubject('A'), isFalse);
    });
  });

  group('StringUtilities', () {
    test('capitalize upper-cases the first letter and lowers the rest', () {
      expect(StringUtilities.capitalize('hELLO'), 'Hello');
      expect(StringUtilities.capitalize(''), '');
      expect(StringUtilities.capitalize('a'), 'A');
    });

    test('capitalizeWords capitalizes every word', () {
      expect(StringUtilities.capitalizeWords('hello world'), 'Hello World');
      expect(StringUtilities.capitalizeWords('the QUICK fox'), 'The Quick Fox');
    });

    test('truncate appends an ellipsis only when over the limit', () {
      expect(StringUtilities.truncate('hello', 10), 'hello');
      expect(StringUtilities.truncate('exact', 5), 'exact');
      expect(StringUtilities.truncate('hello world', 5), 'hello...');
    });

    test('extractTags returns hashtag tokens', () {
      expect(StringUtilities.extractTags('#flutter and #dart'), [
        '#flutter',
        '#dart',
      ]);
      expect(StringUtilities.extractTags('no tags here'), isEmpty);
    });

    test('extractEmails finds addresses in free text', () {
      expect(StringUtilities.extractEmails('reach me@x.com or a@b.org now'), [
        'me@x.com',
        'a@b.org',
      ]);
    });

    test('removeSpecialCharacters keeps alphanumerics and whitespace', () {
      expect(
        StringUtilities.removeSpecialCharacters('Hello, World! 123'),
        'Hello World 123',
      );
    });
  });

  group('NumberUtilities', () {
    test('formatNumber groups thousands', () {
      expect(NumberUtilities.formatNumber(1234567), '1,234,567');
      expect(NumberUtilities.formatNumber(999), '999');
      expect(NumberUtilities.formatNumber(0), '0');
    });

    test('formatDecimal respects the requested precision', () {
      expect(NumberUtilities.formatDecimal(3.14159), '3.14');
      expect(NumberUtilities.formatDecimal(2.0, decimals: 0), '2');
      expect(NumberUtilities.formatDecimal(1.5, decimals: 3), '1.500');
    });

    test('formatPercent scales by 100 with one decimal', () {
      expect(NumberUtilities.formatPercent(0.25), '25.0%');
      expect(NumberUtilities.formatPercent(1), '100.0%');
    });
  });

  group('DateTimeUtilities.formatRelativeTime', () {
    test('buckets recent timestamps', () {
      final now = DateTime.now();
      expect(
        DateTimeUtilities.formatRelativeTime(
          now.subtract(const Duration(seconds: 10)),
        ),
        'just now',
      );
      expect(
        DateTimeUtilities.formatRelativeTime(
          now.subtract(const Duration(minutes: 1)),
        ),
        '1 minute ago',
      );
      expect(
        DateTimeUtilities.formatRelativeTime(
          now.subtract(const Duration(minutes: 5)),
        ),
        '5 minutes ago',
      );
      expect(
        DateTimeUtilities.formatRelativeTime(
          now.subtract(const Duration(hours: 3)),
        ),
        '3 hours ago',
      );
    });

    test('buckets older timestamps into days, weeks, months and years', () {
      final now = DateTime.now();
      expect(
        DateTimeUtilities.formatRelativeTime(
          now.subtract(const Duration(days: 3)),
        ),
        '3 days ago',
      );
      expect(
        DateTimeUtilities.formatRelativeTime(
          now.subtract(const Duration(days: 10)),
        ),
        '1 week ago',
      );
      expect(
        DateTimeUtilities.formatRelativeTime(
          now.subtract(const Duration(days: 45)),
        ),
        '1 month ago',
      );
      expect(
        DateTimeUtilities.formatRelativeTime(
          now.subtract(const Duration(days: 400)),
        ),
        '1 year ago',
      );
    });
  });

  group('DateTimeUtilities day helpers', () {
    test('isToday is true for now and false for yesterday', () {
      final now = DateTime.now();
      expect(DateTimeUtilities.isToday(now), isTrue);
      expect(
        DateTimeUtilities.isToday(now.subtract(const Duration(days: 1))),
        isFalse,
      );
    });

    test('isYesterday is true one day back', () {
      final yesterday = DateTime.now().subtract(const Duration(days: 1));
      expect(DateTimeUtilities.isYesterday(yesterday), isTrue);
      expect(DateTimeUtilities.isYesterday(DateTime.now()), isFalse);
    });
  });
}
