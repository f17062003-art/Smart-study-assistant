# Smart Study Assistant

An AI-powered Flutter app to digitize and organize study materials — scan
textbooks and documents (OCR), capture handwritten notes, add books by
barcode/ISBN, search everything, and chat with a Gemini-powered assistant that
can also generate images. All data is stored **on-device** (no backend).

> Android only. Built with Flutter 3.x / Material 3.

---

## Features

- **Scan documents** — digitize textbooks & printed pages with on-device OCR (Google ML Kit)
- **Capture notes** — photograph and digitize handwritten notes
- **Library** — add books by scanning a barcode / ISBN; browse documents, notes & books
- **Search** — full-text search across documents, notes and books
- **AI Assistant (Gemini)** — markdown answers, copy-to-clipboard, image generation, plus **chat history** and **new chat**
- **Material 3 design system** — light/dark theme, consistent type/colour/radius tokens
- **Offline-first** — local ObjectBox database; nothing leaves the device except AI requests

## Tech stack

Flutter / Dart · Material 3 · ObjectBox (local DB) · Google ML Kit (OCR, barcode,
doc scanner) · googleai_dart (Gemini) · camera / image_picker · share_plus ·
shared_preferences / flutter_secure_storage.

---

## Prerequisites

- **Flutter SDK** 3.27+ (Dart 3.8+) — add `flutter/bin` to your PATH
- **Android Studio** with the Android SDK, Platform-Tools, and an emulator (or a real device)
- **JDK 17** (ships with Android Studio)

Verify your toolchain:

```bash
flutter doctor
flutter doctor --android-licenses
```

## Setup

1. Get the code (clone the repo or unzip the download).
2. Create **`env.json`** in the project root — it's gitignored, so it is **not** in
   the repo/zip. The app reads your Gemini key from it at build time:

   ```json
   { "GOOGLE_GENAI_API_KEY": "<your Gemini API key>" }
   ```

   Get a key at <https://aistudio.google.com>.
3. Fetch dependencies:

   ```bash
   flutter pub get
   ```

> No code generation is required — the ObjectBox generated files
> (`lib/objectbox.g.dart`, `lib/objectbox-model.json`) are committed.

## Run on an emulator or device

```bash
flutter emulators                 # list available AVDs
flutter emulators --launch <id>   # e.g. Pixel_7  (or just start it in Android Studio)
flutter run --dart-define-from-file=env.json
```

While it runs: `r` = hot reload, `R` = hot restart, `q` = quit.

## Build

Release APK:

```bash
flutter build apk --release --dart-define-from-file=env.json
# → build/app/outputs/flutter-apk/app-release.apk
```

- Smaller, per-architecture APKs: add `--split-per-abi`
- Play Store bundle: `flutter build appbundle --dart-define-from-file=env.json`
- Install on a connected device: `adb install -r build/app/outputs/flutter-apk/app-release.apk`

## Tests

```bash
flutter test          # unit tests for utilities + ChatMessage
flutter analyze       # static analysis (should report no issues)
```

---

## Release signing

A proper release build is signed with an **upload keystore** referenced from
`android/key.properties` (both the keystore and this file are gitignored). When
`key.properties` is absent the build **automatically falls back to debug
signing** — fine for local testing and sideloading, but not for the Play Store.

To create your own keystore:

```bash
keytool -genkeypair -v -keystore android/app/upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

Then create `android/key.properties`:

```properties
storePassword=<your store password>
keyPassword=<your key password>
keyAlias=upload
storeFile=upload-keystore.jks
```

⚠️ **Back up the keystore.** If you lose it you can no longer ship updates to the
same app on the Play Store.

## Gotchas

- **`env.json` is required** for the `--dart-define-from-file` flag. If you skip the
  file, drop the flag too (`flutter run`) — the app still runs, but AI chat is
  disabled; everything else works.
- **Document scanner** needs a real device with Google Play Services — it errors on
  a bare emulator. Camera, OCR, AI chat and the library all work on the emulator.

## Project structure

```
lib/
  main.dart            App entry, bottom nav, capture sheet
  screens/             Home, Library, Capture, Search, Settings, detail & chat screens
  services/            ObjectBox DB, storage, ML Kit, AI (Gemini), search, chat history
  models/              Entities: document, note, book, subject, chat message/session
  utils/               Theme, design tokens, utilities
  widgets/             Shared/common widgets
test/                  Unit tests
```
